# NEO AI — Early Access Form · End-to-End Delivery Test Report
**Date:** 4 Aug 2026 · **Relay under test:** `assets/relay.php` (the exact file shipped in this package) · **Harness:** PHP 8.4 built-in server + Chromium (Playwright), sandboxed staging.

## Scope & honesty statement
The full pipeline was executed against the real shipped `relay.php`: browser form → POST JSON → validation/sanitization → rate limiting → transport → JSON verdict → UI state. In staging, the transport ran in `MODE=test` (the relay's staging mode: the fully-composed message is written to an outbox file instead of leaving the sandbox network) and in forced-failure mode. **The final hop — the message physically arriving in the private inbox — can only occur on the deployed production server** (this sandbox has no outbound mail path and the production domain is not yet serving the package). It is verified by the 2-minute post-upload procedure in `docs/DEPLOYMENT.md §4`. No claim of production delivery is made beyond that.

## Results — server behaviour (HTTP, exact responses)
| # | Case | Request | Response | Status |
|---|------|---------|----------|--------|
| 1 | Valid submission | `{"email":"qa-test@example.com","language":"fr","source":"neo-ai-landing","company":""}` | `{"success":true}` · 200 | PASS |
| 2 | Invalid email | `{"email":"not-an-email"}` | `{"success":false,"error":"invalid_request"}` · 422 | PASS |
| 3 | Malformed JSON | `{{{bad` | `{"success":false,"error":"invalid_request"}` · 400 | PASS |
| 4 | GET method | — | `{"success":false,"error":"invalid_request"}` · 405 | PASS |
| 5 | Honeypot filled | `{"email":"bot@spam.com","company":"SpamCorp"}` | `{"success":true}` · 200, **nothing sent** (no outbox entry) | PASS |
| 6 | Rapid duplicate (<15 s) | second valid submit | `{"success":false,"error":"rate_limited"}` · 429, nothing sent | PASS |
| 7 | Header injection (`\r\n Bcc:` in email) | — | rejected `invalid_request` · 422 (control chars stripped + validation) | PASS |
| 8 | Foreign `Origin` header | `Origin: https://evil.example` | `403` refused; same-origin and `https://myneogroup.com` allowed | PASS |

## Results — composed message (test-mode outbox, verbatim)
```
To: <private inbox — held server-side only>
Subject: NEO AI — New Early Access Request

New Early Access request — NEO AI

Email:      qa-test@example.com
Time (UTC): 2026-08-04 08:46:50 UTC
Language:   fr
Source:     neo-ai-landing
Page:       https://myneogroup.com/neoai/
IP:         127.0.0.1
User-Agent: curl/8.5.0
```
Contains the submitted email, UTC timestamp, visitor language, source page, IP and user agent — as required.

## Results — browser UI (real form, real dropdown)
- French UI, invalid email → inline message « Veuillez saisir une adresse e-mail valide. » — no request sent. **PASS**
- French UI, valid email → button becomes « Demande reçue ✓ », input locked, exactly one outbox message written. **PASS**
- **Delivery-failure honesty:** all transports force-disabled → relay returned `502 {"success":false,"error":"delivery_failed"}`; the page showed "Something went wrong - please try again.", button re-enabled, **no success state shown**. **PASS**
- Duplicate client-side submission after success: blocked by the form's `done` guard. **PASS**
- The user's email appears in no URL, query string or client log; server log stores hashed identifiers only. **PASS**

## Privacy of the destination inbox
`grep`-verified: the inbox address appears in **zero** client-delivered files (HTML/CSS/JS). It exists only in `relay.php` (server-side) and optionally in the operator's config outside the webroot.

## Remaining step for the operator (2 minutes, after upload)
Run `docs/DEPLOYMENT.md §4` on the live server: one curl + one visible-form submission, then confirm the message in the inbox. Until that check passes on production, delivery is verified end-to-end **up to and including the transport handoff**, not the mailbox arrival.
