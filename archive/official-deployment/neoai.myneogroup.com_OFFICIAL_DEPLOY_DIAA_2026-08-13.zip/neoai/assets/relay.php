<?php
/**
 * NEO AI — Early Access relay (production)
 * Browser form → POST JSON here → validate/sanitize → email the private inbox → honest JSON result.
 *
 * The destination inbox exists ONLY server-side (this file + optional config), never in client code.
 * Transports, in order of preference:
 *   1. SMTP  — if a config file provides SMTP credentials (recommended: authenticated submission)
 *   2. mail()— PHP sendmail (works on standard GoDaddy/cPanel shared hosting)
 *   3. FormSubmit HTTP forward — fallback relay (requires its one-time activation click)
 * Success is returned ONLY if the active transport accepted the message. No fabricated success.
 *
 * Optional config file (keep OUTSIDE the public webroot — see server-config/relay.config.example.php):
 *   looked up at: dirname(DOCUMENT_ROOT) . '/neoai-relay.config.php'
 *   then:         __DIR__ . '/relay.config.php'   (works, but above-webroot is preferred)
 */

declare(strict_types=1);
ini_set('display_errors', '0');            /* never expose PHP errors publicly */
error_reporting(E_ALL);

const INBOX      = 'myneogroup@protonmail.ch';
const SUBJECT    = 'NEO AI — New Early Access Request';
const FROM_LOCAL = 'no-reply';             /* sender becomes no-reply@<host> unless config overrides */
const ALLOWED_ORIGINS = ['https://myneogroup.com', 'https://www.myneogroup.com'];
const MAX_BODY   = 8192;
const RATE_MAX_PER_HOUR = 5;               /* per IP */
const RATE_MIN_INTERVAL = 15;              /* seconds between submissions per IP */

header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');

/* ---- CORS: restrict to the production origin (same-origin requests carry no Origin or match) ---- */
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '') {
    $sameOrigin = (parse_url($origin, PHP_URL_HOST) ?? '') === (explode(':', (string)($_SERVER['HTTP_HOST'] ?? ''))[0]);
    if ($sameOrigin || in_array($origin, ALLOWED_ORIGINS, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    } else {
        http_response_code(403);
        echo '{"success":false,"error":"invalid_request"}';
        exit;
    }
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
    http_response_code(204);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo '{"success":false,"error":"invalid_request"}';
    exit;
}

/* ---- helpers ---- */
function respond(int $code, array $payload): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}
function clean_line(string $v, int $max): string {
    /* header-injection-proof: strip CR/LF/NUL and control chars, cap length */
    $v = preg_replace('/[\r\n\x00-\x1F\x7F]/', '', $v) ?? '';
    return mb_substr(trim($v), 0, $max);
}
function client_ip(): string {
    return clean_line((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 45);
}
function logline(string $status, string $email): void {
    /* minimal, privacy-preserving log: time + status + hashed email + hashed ip */
    $cfg = $GLOBALS['NEOAI_CFG'] ?? [];
    $path = $cfg['LOG_PATH'] ?? (sys_get_temp_dir() . '/neoai-relay.log');
    $line = gmdate('c') . ' ' . $status
          . ' e:' . substr(hash('sha256', strtolower($email)), 0, 12)
          . ' ip:' . substr(hash('sha256', client_ip()), 0, 12) . "\n";
    @file_put_contents($path, $line, FILE_APPEND | LOCK_EX);
}

/* ---- optional config (SMTP etc.) ---- */
$NEOAI_CFG = [];
$docroot = $_SERVER['DOCUMENT_ROOT'] ?? __DIR__;
foreach ([dirname($docroot) . '/neoai-relay.config.php', __DIR__ . '/relay.config.php'] as $cfgFile) {
    if (is_readable($cfgFile)) { $NEOAI_CFG = (array)(include $cfgFile); break; }
}

/* ---- parse + validate ---- */
$raw = file_get_contents('php://input');
if ($raw === false || $raw === '' || strlen($raw) > MAX_BODY) {
    respond(400, ['success' => false, 'error' => 'invalid_request']);
}
$data = json_decode($raw, true);
if (!is_array($data)) {
    respond(400, ['success' => false, 'error' => 'invalid_request']);
}

/* honeypot: bots fill the hidden field → pretend success, send nothing */
$honey = (string)($data['company'] ?? '');
if ($honey !== '') { logline('honeypot', '-'); respond(200, ['success' => true]); }

$email    = clean_line((string)($data['email'] ?? ''), 254);
$language = clean_line((string)($data['language'] ?? ''), 8);
$source   = clean_line((string)($data['source'] ?? ''), 64);
if ($language === '' || !preg_match('/^[a-z]{2}(-[A-Za-z]{2,4})?$/', $language)) { $language = 'unknown'; }
if ($source === '') { $source = 'neo-ai-landing'; }

if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    logline('invalid_email', $email);
    respond(422, ['success' => false, 'error' => 'invalid_request']);
}

/* ---- rate limiting (file-based, per IP) ---- */
$rlFile = sys_get_temp_dir() . '/neoai-rl-' . hash('sha256', client_ip()) . '.json';
$now = time();
$hist = [];
if (is_readable($rlFile)) {
    $hist = json_decode((string)@file_get_contents($rlFile), true);
    if (!is_array($hist)) { $hist = []; }
}
$hist = array_values(array_filter($hist, fn($t) => is_int($t) && $now - $t < 3600));
if (count($hist) >= RATE_MAX_PER_HOUR || (count($hist) > 0 && $now - max($hist) < RATE_MIN_INTERVAL)) {
    logline('rate_limited', $email);
    respond(429, ['success' => false, 'error' => 'rate_limited']);
}
$hist[] = $now;
@file_put_contents($rlFile, json_encode($hist), LOCK_EX);

/* ---- compose message (all user values sanitized; none reach headers except the validated email as Reply-To) ---- */
$ua   = clean_line((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 300);
$page = clean_line((string)($_SERVER['HTTP_REFERER'] ?? ''), 300);
$bodyLines = [
    'New Early Access request — NEO AI',
    '',
    'Email:      ' . $email,
    'Time (UTC): ' . gmdate('Y-m-d H:i:s') . ' UTC',
    'Language:   ' . $language,
    'Source:     ' . $source,
    'Page:       ' . ($page !== '' ? $page : 'https://myneogroup.com/neoai/'),
    'IP:         ' . client_ip(),
    'User-Agent: ' . $ua,
];
$body = implode("\r\n", $bodyLines) . "\r\n";

/* ---- transports ---- */
function send_smtp(array $cfg, string $to, string $subject, string $body, string $replyTo): bool {
    $host = (string)($cfg['SMTP_HOST'] ?? '');
    if ($host === '') { return false; }
    $port = (int)($cfg['SMTP_PORT'] ?? 465);
    $user = (string)($cfg['SMTP_USER'] ?? '');
    $pass = (string)($cfg['SMTP_PASS'] ?? '');
    $from = (string)($cfg['SMTP_FROM'] ?? $user);
    $timeout = 12;
    $remote = ($port === 465 ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $fp = @stream_socket_client($remote, $ec, $em, $timeout, STREAM_CLIENT_CONNECT,
        stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
    if (!$fp) { return false; }
    stream_set_timeout($fp, $timeout);
    $expect = function (array $codes) use ($fp): bool {
        $line = '';
        do { $line = fgets($fp, 512); if ($line === false) { return false; } }
        while (isset($line[3]) && $line[3] === '-');
        return in_array((int)substr($line, 0, 3), $codes, true);
    };
    $say = function (string $cmd) use ($fp): void { fwrite($fp, $cmd . "\r\n"); };
    if (!$expect([220])) { fclose($fp); return false; }
    $say('EHLO myneogroup.com'); if (!$expect([250])) { fclose($fp); return false; }
    if ($port === 587) {  /* STARTTLS */
        $say('STARTTLS'); if (!$expect([220])) { fclose($fp); return false; }
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { fclose($fp); return false; }
        $say('EHLO myneogroup.com'); if (!$expect([250])) { fclose($fp); return false; }
    }
    if ($user !== '') {
        $say('AUTH LOGIN');           if (!$expect([334])) { fclose($fp); return false; }
        $say(base64_encode($user));   if (!$expect([334])) { fclose($fp); return false; }
        $say(base64_encode($pass));   if (!$expect([235])) { fclose($fp); return false; }
    }
    $say('MAIL FROM:<' . $from . '>');            if (!$expect([250])) { fclose($fp); return false; }
    $say('RCPT TO:<' . $to . '>');                if (!$expect([250, 251])) { fclose($fp); return false; }
    $say('DATA');                                 if (!$expect([354])) { fclose($fp); return false; }
    $headers = 'From: NEO AI <' . $from . ">\r\n"
             . 'Reply-To: <' . $replyTo . ">\r\n"
             . 'To: <' . $to . ">\r\n"
             . 'Subject: ' . $subject . "\r\n"
             . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=utf-8\r\n";
    $data = $headers . "\r\n" . str_replace("\r\n.", "\r\n..", $body) . "\r\n.";
    $say($data);                                  $ok = $expect([250]);
    $say('QUIT'); fclose($fp);
    return $ok;
}
function send_mail(string $to, string $subject, string $body, string $replyTo): bool {
    $host = clean_line((string)($_SERVER['SERVER_NAME'] ?? 'myneogroup.com'), 100);
    if ($host === '' || $host === 'localhost') { $host = 'myneogroup.com'; }
    $headers = 'From: NEO AI <' . FROM_LOCAL . '@' . $host . ">\r\n"
             . 'Reply-To: <' . $replyTo . ">\r\n"
             . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=utf-8\r\n";
    return @mail($to, $subject, $body, $headers);
}
function send_formsubmit(string $to, string $subject, array $fields): bool {
    if (!function_exists('curl_init')) { return false; }
    $ch = curl_init('https://formsubmit.co/ajax/' . rawurlencode($to));
    curl_setopt_array($ch, [
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => json_encode(array_merge($fields, ['_subject' => $subject, '_template' => 'table'])),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 12,
    ]);
    $res  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res === false || $code < 200 || $code >= 300) { return false; }
    $j = json_decode((string)$res, true);
    return is_array($j) && (($j['success'] ?? '') === 'true' || ($j['success'] ?? false) === true);
}

$delivered = false;
$mode = getenv('NEOAI_RELAY_MODE') ?: (string)($NEOAI_CFG['MODE'] ?? 'auto');
if ($mode === 'test') {
    /* staging/e2e mode: full pipeline runs, message written to an outbox file instead of sent */
    $outdir = (string)($NEOAI_CFG['LOG_PATH'] ?? sys_get_temp_dir());
    if (is_dir($outdir) === false) { $outdir = sys_get_temp_dir(); }
    $delivered = (bool)@file_put_contents(
        rtrim($outdir, '/') . '/neoai-outbox-' . gmdate('Ymd-His') . '-' . substr(hash('sha256', $email . microtime()), 0, 6) . '.eml',
        'To: ' . INBOX . "\r\nSubject: " . SUBJECT . "\r\n\r\n" . $body);
} else {
    if (!$delivered && !empty($NEOAI_CFG['SMTP_HOST'])) { $delivered = send_smtp($NEOAI_CFG, INBOX, SUBJECT, $body, $email); }
    if (!$delivered && ($NEOAI_CFG['DISABLE_MAIL'] ?? false) !== true) { $delivered = send_mail(INBOX, SUBJECT, $body, $email); }
    if (!$delivered) { $delivered = send_formsubmit(INBOX, SUBJECT, ['email' => $email, 'language' => $language, 'source' => $source, 'time_utc' => gmdate('c')]); }
}

if ($delivered) {
    logline('delivered', $email);
    respond(200, ['success' => true]);
}
logline('delivery_failed', $email);
respond(502, ['success' => false, 'error' => 'delivery_failed']);
