<?php
/**
 * NEO AI relay configuration — EXAMPLE (no real credentials).
 *
 * RECOMMENDED LOCATION (outside the public webroot):
 *   /home/<account>/neoai-relay.config.php
 *   i.e. one level ABOVE public_html — relay.php looks there first:
 *   dirname(DOCUMENT_ROOT) . '/neoai-relay.config.php'
 *
 * Fallback location (works, less ideal): public_html/neoai/assets/relay.config.php
 * (the shipped .htaccess denies direct HTTP access to that filename).
 *
 * WITHOUT this file the relay still works: it uses PHP mail() (standard on
 * GoDaddy/cPanel), then the FormSubmit HTTP relay as a final fallback.
 * With SMTP configured, delivery is authenticated and most reliable.
 */
return [
    /* --- transport preference ------------------------------------------ */
    // 'MODE' => 'auto',            // 'auto' (default) | 'test' (writes .eml files instead of sending)

    /* --- SMTP (recommended): any transactional provider or mailbox SMTP - */
    // 'SMTP_HOST' => 'smtp.your-provider.com',
    // 'SMTP_PORT' => 465,          // 465 = implicit TLS, 587 = STARTTLS
    // 'SMTP_USER' => 'no-reply@myneogroup.com',
    // 'SMTP_PASS' => '********',   // real value ONLY in the live file outside webroot
    // 'SMTP_FROM' => 'no-reply@myneogroup.com',

    /* --- options -------------------------------------------------------- */
    // 'DISABLE_MAIL' => true,      // skip PHP mail() (e.g. to force SMTP-only)
    // 'LOG_PATH' => '/home/<account>/neoai-relay.log',  // status log (hashed identifiers only)
];
