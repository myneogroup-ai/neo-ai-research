# NEO AI — Detailed Deployment & Operations (v17.2)

Target: `https://myneogroup.com/neoai/` on GoDaddy shared hosting (Apache + PHP). The main WordPress site at the domain root is not touched: WordPress's standard `.htaccess` serves real files/directories without rewriting, so `/neoai/` coexists cleanly. If a security plugin blocks unknown directories, whitelist `/neoai/`.

## 1 · Upload
Upload the contents of `neoai/` into `public_html/neoai/` exactly as structured. File permissions: default (644 files / 755 folders) are fine; `relay.php` needs nothing special.

## 2 · Email relay — how it works
The "Request Early Access" form POSTs JSON (`email`, `language`, `source`, honeypot field) to `assets/relay.php`, same origin. The relay:

- accepts POST + JSON only (405/400 otherwise), max 8 KB body;
- restricts cross-origin calls to `https://myneogroup.com` (+ www) — same-origin always allowed;
- validates the email server-side (`FILTER_VALIDATE_EMAIL`), strips all control characters from every value (header-injection-proof), never places user input in mail headers except the validated address as `Reply-To`;
- drops bot submissions silently via the hidden honeypot field;
- rate-limits per IP (5/hour, minimum 15 s between submissions) → `429 {"success":false,"error":"rate_limited"}`;
- composes the message to the private inbox with: submitted email, UTC timestamp, interface language, source, page, IP, user agent;
- tries transports in order: **SMTP** (if configured) → **PHP `mail()`** → **FormSubmit HTTP relay**;
- returns `{"success":true}` ONLY when a transport genuinely accepted the message; otherwise `502 {"success":false,"error":"delivery_failed"}` — the page then shows an error, never a fake success;
- logs only status + hashed identifiers (no plaintext personal data), `display_errors` off.

The destination inbox appears ONLY inside `relay.php` (and your optional config) — never in any client-delivered file.

## 3 · Configure SMTP (recommended)
1. Copy `server-config/relay.config.example.php` to `/home/<your-account>/neoai-relay.config.php` (one level ABOVE `public_html`).
2. Fill `SMTP_HOST/PORT/USER/PASS/FROM` with a mailbox or transactional provider (e.g. a `no-reply@myneogroup.com` mailbox created in cPanel, port 465).
3. No restart needed — the relay picks the file up on the next request.
Without SMTP config, PHP `mail()` is used (works on GoDaddy; make sure SPF for myneogroup.com includes the GoDaddy mail servers for best deliverability). The FormSubmit fallback requires its one-time activation: the FIRST submission triggers a confirmation email to the inbox — click it once.

## 4 · Verify email delivery (2 minutes, after upload)
1. `curl -X POST https://myneogroup.com/neoai/assets/relay.php -H "Content-Type: application/json" -d '{"email":"your-test@yourdomain.com","language":"en","source":"post-deploy-check"}'`
   → expect `{"success":true}`.
2. Check the inbox: subject **NEO AI — New Early Access Request**, body listing the test address + UTC time + language.
3. Negative check: same command with `"email":"not-an-email"` → expect `{"success":false,"error":"invalid_request"}`.
4. Submit once through the visible form on the page and confirm the button flips to the translated "Request received ✓" state.
The full pre-production test matrix (validation, honeypot, rate limit, injection, CORS, delivery-failure honesty, multi-language UI) with evidence is in `qa/QA_EMAIL_DELIVERY_TEST.md`.

## 5 · SEO files
`sitemap.xml` is served at `/neoai/sitemap.xml`. The authoritative `robots.txt` is the WordPress one at the domain root — add these two lines to it:
```
Allow: /neoai/
Sitemap: https://myneogroup.com/neoai/sitemap.xml
```
(The `robots.txt` inside `/neoai/` documents this and is harmless where it is.)

## 6 · Cache
`.htaccess` sets 7-day caching for CSS/JS and no-cache for HTML. After future updates, hard-refresh (Ctrl/Cmd-Shift-R) or bump filenames; GoDaddy has no server cache to clear by default. If Cloudflare is later added, purge its cache after each upload.

## 7 · Rollback
Keep the previous `neoai/` folder as `neoai_backup_<date>/`; rollback = renaming folders. No state is stored server-side except relay logs.
