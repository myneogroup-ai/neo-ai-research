# NEO AI — Public Website · Production Package (v17.2)

Deploy target: **https://myneogroup.com/neoai/** (subdirectory — NOT the domain root).
Everything is self-contained; after upload the site works immediately. No build step, no database, no manual edits to HTML/CSS/JS.

## 3-minute deployment

1. Upload the **contents of the `neoai/` folder** of this package into `public_html/neoai/` (cPanel File Manager or SFTP), keeping the structure:

```
public_html/neoai/
├── index.html
├── .htaccess            (optional but recommended — caching + config-file protection)
├── robots.txt           (see note inside — authoritative robots stays at the WP root)
├── sitemap.xml
└── assets/
    ├── css/site.min.css
    ├── js/  (7 files: three.min.js, vendor.min.js, app-*.js)
    ├── favicon.svg
    └── relay.php        (email relay — the private inbox exists ONLY here, server-side)
```

2. Open https://myneogroup.com/neoai/ — the site is live. All paths are relative, so the subdirectory works as-is.
3. Email relay: works out of the box on GoDaddy/cPanel via PHP `mail()` (with FormSubmit as automatic fallback). For authenticated SMTP (recommended), copy `server-config/relay.config.example.php` to `/home/<account>/neoai-relay.config.php` (one level ABOVE `public_html`), fill the SMTP values, done. **Never put real credentials in any file inside `public_html`.**
4. Run the 2-minute post-upload email check in `DEPLOYMENT.md` (section "Verify email delivery").

## Requirements
PHP 7.4+ (8.x recommended) with cURL — standard on GoDaddy shared hosting. Apache with `.htaccess` support (default). Nothing else.

## What is NOT in this package
The Investor Portal / Data Room / KYC / NDA workflows are a separate future project and are intentionally excluded. The site's "Request Investor Access" button links to `https://myneogroup.com/dataroom` (already deployed separately).

## Package map
- `neoai/` — the deployable site (upload its contents).
- `server-config/relay.config.example.php` — SMTP config template (credentials empty).
- `preview/` — single-file version you can double-click locally to view the full cinematic site (not for deployment).
- `docs/` — this file, the detailed `DEPLOYMENT.md`, `CHANGELOG.md`, `MODIFIED_FILES.md`.
- `qa/` — machine-readable QA reports (metrics, i18n, links/claims/code, translation rendering, email delivery test, visual report + 40 captures).
