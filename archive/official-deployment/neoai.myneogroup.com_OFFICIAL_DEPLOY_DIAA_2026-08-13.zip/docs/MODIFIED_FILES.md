# v17.2 — Modified / added files (vs v17.1)

## Modified
- `neoai/index.html` — (a) orchestration section: disclaimer moved out of the `.tokens` container to its own row below; `.tokens` switched to a symmetric 2×2 grid (single column ≤640px); (b) hidden honeypot field added to the Early-Access form; (c) form JS: payload now `{email, language, source, company}` and success shown ONLY on `{"success":true}` (422 → email error; failure/rate-limit → error state); (d) `<link rel="icon">` added. No other markup, copy, style or script changed.
- `neoai/assets/relay.php` — rebuilt as the production relay (validation, sanitization, honeypot, rate limiting, CORS, exact JSON contract, SMTP/mail()/FormSubmit transports, honest failure semantics, hashed logging).

## Added
- `neoai/assets/favicon.svg`
- `neoai/robots.txt`, `neoai/sitemap.xml`, `neoai/.htaccess`
- `server-config/relay.config.example.php`
- `docs/README_DEPLOYMENT.md`, `docs/DEPLOYMENT.md`, `docs/CHANGELOG.md`, `docs/MODIFIED_FILES.md`
- `qa/QA_TRANSLATION_REPORT.json`, `qa/QA_EMAIL_DELIVERY_TEST.md` (+ refreshed QA_METRICS/I18N/LINKS reports and visual report)

## Explicitly unchanged (regression lock)
Opening halo · cinematic hero + orbital cards + WebGL sequence · scroll choreography · Foundation Model holographic chamber · Industry Universe sequence · NEO Intelligence · Business Model · investor section + Data Room URL + "Request Investor Access" link · LILI identity · 18-language selector · legal modal · cookie notice · SEO metadata · responsive behaviour · performance safeguards · reduced-motion support · visual identity.

## Excluded from this delivery (separate future project)
Investor Portal / Data Room / KYC / NDA / authentication files.
