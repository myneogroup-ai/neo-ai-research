# README FIRST

**NEO AI Research Program — production update for `neoai.myneogroup.com`**
Package `research-delta-1.0.0` · built 13 August 2026 · against deployed `v17.2`

---

## What this is

A delta. It adds the `/research/` section to the live site and changes six
existing files. It does not rebuild the site, does not touch the landing page's
hero, WebGL engine, scroll choreography, Mission Control section, investor
section or Early-Access relay, and does not modify a single existing line of
markup — **every change to `index.html` is an insertion.**

## Deploy it in four minutes

```bash
# 1. Back up. Rollback depends on this and nothing else.
cp -a public_html/  public_html.bak-before-research-delta/

# 2. Verify you are patching the file this package was built against.
sha256sum public_html/index.html
# must print: 836bbfbaec245e3ce13449f8595837ae77740cf60fcc24b410ba72db68dc1ee6
# If it does not, STOP and read DEPLOYMENT_ORDER.md, precondition P1.

# 3. Upload the CONTENTS of upload/ into the document root, preserving paths.
#    It overwrites index.html, robots.txt, sitemap.xml and .htaccess, and adds
#    everything else. Nothing else on the server is touched.

# 4. Check.
curl -sI https://neoai.myneogroup.com/research/ | head -1        # 200
curl -sI https://neoai.myneogroup.com/id/NEO-AI-R-009 | head -1  # 302
curl -s  https://neoai.myneogroup.com/llms.txt | head -1         # # NEO AI Research
```

Then work through `QA_CHECKLIST.md`. It has 118 checks and the first fourteen
are the ones that matter.

## Read these, in this order

| Read | Why |
|---|---|
| `DEPLOYMENT_ORDER.md` | The three preconditions, then the exact sequence. **P2 will fail the deploy if it is not true.** |
| `MODIFICATIONS.md` | Every existing file that changes, why, and the exact edit |
| `AUDIT_CTO_FINAL.md` | What is in this package, what is deliberately not, and the eight things it does not fix |
| `PREEXISTING_DEFECTS.md` | Seven defects on the live site older than this release. Four are fixed here. Three need a decision |
| `QA_CHECKLIST.md` | After deploying |
| `ROLLBACK.md` | Before deploying, so you have read it before you need it |

## The four things most likely to trip you

**1. The document root must be the subdomain root.**
Every asset path in the new pages is root-relative (`/assets/…`). The deployed
`index.html` uses relative paths (`assets/…`), which work at either. If
`neoai.myneogroup.com` serves from a subdirectory rather than from its own
document root, the research pages will render unstyled. `DEPLOYMENT_ORDER.md`
precondition P2 tells you how to check in ten seconds.

**2. `.htaccess` is replaced, not appended to.**
The new file carries every directive from your v17.2 `.htaccess` verbatim in
block 1. Diff it before uploading if you have changed it since.

**3. Two files are dotfiles and most FTP clients hide them.**
`.htaccess` at the root and `feeds/.htaccess`. If your client does not show
hidden files, both will be silently skipped: the first breaks every route added
by this release, the second serves the Atom feeds with the wrong media type.
Enable "show hidden files" before you start, and verify after upload:

```bash
curl -sI https://neoai.myneogroup.com/id/NEO-AI-R-009 | head -1        # 302
curl -sI https://neoai.myneogroup.com/feeds/all.xml | grep -i content-type
# must be application/atom+xml
```

**4. Script order in `index.html` is load-bearing.**
`research-nav-i18n.min.js` must sit between `app-i18n.min.js` and
`app-runtime.min.js`. If it moves, the Research link reads "Research" in all
eighteen languages instead of being translated. Degraded, not broken — but the
supplied `index.html` already has it right, so just use that file.

## What is actually published

One publication. That is not an omission.

Of the six documents approved for Public Wave 1, five carry
`content_present: false` in the frozen register: their public texts are gated on
editorial changes that have not been applied, and two of those changes remove
material classified above PUBLIC. Three further papers have text and are marked
`publish: false`, held for Wave 1b.

**`NEO-AI-R-009` is the only publishable full text in the corpus today.** The
package builds the entire library apparatus around it — indexes, the capability
register, the glossary term set, the roadmap, discovery, structured data, search
— so that Wave 1b is a content import and not another release. Adding the other
five would have required writing them, and the corpus's own rules and your
project instructions both forbid that.

When a text clears: drop the markdown into `build/corpus/content/…` at the path
the register already records, set `content_present`, re-run two commands. See
`DEVELOPER_HANDOFF.md` §5.

## Package contents

```
PRODUCTION_UPDATE/
├── upload/                     ← THIS is what goes on the server. 68 files.
├── build/                      ← how it was produced, and how to rebuild
├── MODIFICATIONS_index.diff    ← the landing-page diff, +66 / −0 lines
├── QA_EVIDENCE/                ← screenshots and the conformance run
└── *.md                        ← the documentation set, 20 files
```

`upload/` is complete and pre-built. **You do not need to run the build to
deploy.** The build exists so the next wave is reproducible.
