# Structured data

## The governing rule

**Structured data must never assert more than the visible page.**

Every property in every JSON-LD block corresponds to something a reader can see.
No hidden authorship, no invented date, no rating, no count that is not rendered,
no `about` entity the page does not discuss.

This is the rule this corpus is most likely to break, because emitting a richer
block is always tempting and nothing visibly goes wrong when you do. A
`ScholarlyArticle` asserting citations the page does not render is a false
machine-readable claim made by a corpus whose entire argument is about not
making false claims.

## The entity graph

One `@id` per entity, referenced by `@id` everywhere, never restated inline.

| Entity | `@id` | Defined on |
|---|---|---|
| `Person`, Mickael Mosse | `https://mickaelmosse.ai/about/#person` | founder site (referenced only) |
| `Organization`, NEO AI Research Program | `…/research/about/#neo-ai-research` | `/research/about/` |
| `Organization`, NEO TECH LABS | `…/company/#neo-tech-labs` | `/` (M-01) |
| `Organization`, My NEO Group | `https://myneogroup.com/#my-neo-group` | `/` (M-01) |
| `WebSite` | `…/#website` | `/` (M-01) |
| `SoftwareApplication` + `Brand`, NEO AI | `…/#neo-ai` | `/` (M-01) |
| `DefinedTermSet` | `…/research/glossary/#set` | `/research/glossary/` |
| `Dataset`, Capability Register | `…/research/capability-register/#dataset` | the register |
| `ScholarlyArticle` | `<canonical>#article` | the publication |
| `BreadcrumbList` | `<canonical>#breadcrumb` | every page with a trail |
| `CollectionPage` | `<url>#collection` | indexes and hubs |

`schema/entities.jsonld` is also served as a file, so the graph is fetchable
independently of any page.

**This is why M-01 and the research tree deploy together.** Three of the `@id`
nodes above are defined by M-01. Deploying the research tree without it leaves
dangling references. Check SD3 enforces resolution across the whole tree.

## Per-page types

| Page | Types |
|---|---|
| `/` | `WebSite`, `SoftwareApplication`+`Brand`, 3 × `Organization` |
| a publication | `ScholarlyArticle`, `BreadcrumbList` |
| library, category, hub | `CollectionPage`, `BreadcrumbList` |
| capability register | `Dataset`, `BreadcrumbList` |
| a capability page | `BreadcrumbList` only |
| glossary | `DefinedTermSet`, `BreadcrumbList` |
| about | `Organization`, `BreadcrumbList` |
| methodology | `WebPage`, `BreadcrumbList` |
| `/search/`, `/404.html` | `BreadcrumbList` / none |

## The claim-class property set

The most valuable structured-data decision available to this corpus, and it is
specific to it. Each article carries four `PropertyValue` nodes in
`variableMeasured`:

| name | R-009 |
|---|---|
| `claims-established` | 4 |
| `claims-architectural-interpretation` | 4 |
| `claims-design-intent` | 3 |
| `claims-open-problem` | 3 |

**Counted from the rendered evidence table at build time, never typed.** A typed
count goes stale on the next edit and becomes exactly the false machine-readable
claim the rest of this document exists to prevent. Check **SD6** compares each
value against the number rendered in the page's claim bar and fails on any
disagreement.

A retrieval system reading only the structured data learns that this corpus
distinguishes evidence from interpretation from intent from an open question.

## Highwire tags

On the publication canonical: `citation_title`, `citation_author`,
`citation_publication_date`, `citation_technical_report_institution`,
`citation_pdf_url`.

**`citation_technical_report_number` is omitted**, because R-009's identifier is
requested and not allocated. It is omitted rather than filled with a requested
one, and the page says so in plain text. Checks SD8 and SD8b assert that the
Highwire tag and the article node's `identifier` are absent together.

## Deliberate absences

| Absent | Why |
|---|---|
| `DefinedTerm` nodes | SD5 requires the description to be byte-identical to a rendered definitional sentence. No definition is published yet, so no node may be emitted. The `DefinedTermSet` alone is correct |
| `offers` | The product is not generally available. Markup saying otherwise is a false claim in the plainest sense |
| `Review`, `AggregateRating`, `Rating` | The corpus has no reviews and inventing the markup invents the reviews |
| `interactionStatistic`, view or download counts | Nothing renders them |
| `sameAs` on the `Person` | Only real, controlled, reciprocal profiles qualify. A `sameAs` to a profile that does not link back is an unverifiable assertion |
| ORCID | Not registered. Omitted rather than filled with a placeholder — and it **blocks first publication** under the corpus's own standard. `AUDIT_CTO_FINAL.md` §4, F-1 |
| `hreflang` | No per-language URL exists |
| `image` / `og:image` | No card image exists yet. `IMAGES.md` §3 |

The frozen `schema/entities.jsonld` carried the literal strings
`ORCID_TO_BE_REGISTERED_BEFORE_FIRST_PUBLICATION` and
`REAL_CONTROLLED_RECIPROCAL_PROFILES_ONLY`. **Publishing those would have been
worse than publishing nothing.** The served graph omits both fields.

## Validation, in the build

| # | Check | State |
|---|---|---|
| SD1 | every block parses | pass |
| SD3 | every referenced `@id` resolves to a node defined once | pass |
| SD6 | `variableMeasured` equals the rendered counts | pass |
| SD7 | no prohibited type or property | pass |
| SD8 | Highwire report number and article identifier agree | pass |
| SD10 | every capability status in markup matches the register | pass |
| SD-BC | `BreadcrumbList` only where a trail is rendered | pass |

Not automatable, and therefore in `QA_CHECKLIST.md` §F as manual checks: SD2
(every property has a rendered counterpart) is spot-checked at five properties,
and SD4 (`sameAs` reciprocity) is moot while no `sameAs` is emitted.

## Where the register is the authority

Every capability status rendered anywhere — in a claim chip, in the capability
summary table, on a capability page, in the register, in `capabilities.json` —
is resolved from `registers/capabilities.json` when the page is built. **The
build fails** if a text claims a key that is not in the register, or claims a
status the register disagrees with. There is no override and no default value.

That rule is the reason this corpus can make design-intent claims at all, and
its value comes entirely from never being waived once.
