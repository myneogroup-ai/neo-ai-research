# File tree

The `upload/` directory. Its **contents** go into the document root, preserving paths.

```
<document root>/
├── .htaccess
├── 404.html
├── capabilities.json
├── index.html
├── llms.txt
├── robots.txt
├── sitemap.xml
├── assets/
│   ├── search-index.json
│   ├── css/
│   │   ├── nav-fit.min.css
│   │   ├── research.min.css
│   ├── js/
│   │   ├── legal-deeplink.min.js
│   │   ├── research-nav-i18n.min.js
│   │   ├── research.min.js
├── feeds/
│   ├── .htaccess
│   ├── all.xml
│   ├── institutional.xml
│   ├── papers.xml
│   ├── technical-notes.xml
│   ├── updates.xml
├── pdf/
│   ├── NEO-AI-R-009/
│   │   ├── v1.0.pdf
├── research/
│   ├── index.html
│   ├── about/
│   │   ├── index.html
│   ├── authors/
│   │   ├── index.html
│   │   ├── mickael-mosse/
│   │   │   ├── index.html
│   ├── capability-register/
│   │   ├── index.html
│   │   ├── assurance.eval-harness/
│   │   │   ├── index.html
│   │   ├── brain/
│   │   │   ├── index.html
│   │   ├── brain.cost-engine/
│   │   │   ├── index.html
│   │   ├── brain.event-bus/
│   │   │   ├── index.html
│   │   ├── brain.evidence-layer/
│   │   │   ├── index.html
│   │   ├── brain.evidence-ledger/
│   │   │   ├── index.html
│   │   ├── brain.governance/
│   │   │   ├── index.html
│   │   ├── brain.knowledge-graph/
│   │   │   ├── index.html
│   │   ├── brain.memory/
│   │   │   ├── index.html
│   │   ├── brain.router/
│   │   │   ├── index.html
│   │   ├── brain.task-graph/
│   │   │   ├── index.html
│   │   ├── brain.validation/
│   │   │   ├── index.html
│   │   ├── dataroom.backend/
│   │   │   ├── index.html
│   │   ├── dataroom.frontend/
│   │   │   ├── index.html
│   │   ├── deployment.cloud/
│   │   │   ├── index.html
│   │   ├── deployment.onprem/
│   │   │   ├── index.html
│   │   ├── deployment.vpc/
│   │   │   ├── index.html
│   │   ├── foundation-model/
│   │   │   ├── index.html
│   │   ├── lili/
│   │   │   ├── index.html
│   │   ├── mission-control/
│   │   │   ├── index.html
│   │   ├── mission.envelope/
│   │   │   ├── index.html
│   │   ├── neo-intelligence/
│   │   │   ├── index.html
│   │   ├── pilots/
│   │   │   ├── index.html
│   │   ├── public-website/
│   │   │   ├── index.html
│   ├── glossary/
│   │   ├── index.html
│   ├── institutional/
│   │   ├── index.html
│   ├── methodology/
│   │   ├── index.html
│   ├── papers/
│   │   ├── index.html
│   │   ├── model-intelligence-to-system-intelligence/
│   │   │   ├── index.html
│   ├── roadmap/
│   │   ├── index.html
│   ├── technical-notes/
│   │   ├── index.html
│   ├── topics/
│   │   ├── multi-model/
│   │   │   ├── index.html
│   │   ├── system-intelligence/
│   │   │   ├── index.html
│   ├── updates/
│   │   ├── index.html
├── schema/
│   ├── capabilities-v1.json
│   ├── entities.jsonld
├── search/
│   ├── index.html
├── sitemaps/
│   ├── capability.xml
│   ├── figures.xml
│   ├── glossary.xml
│   ├── indexes.xml
│   ├── platform.xml
│   ├── publications.xml
```
