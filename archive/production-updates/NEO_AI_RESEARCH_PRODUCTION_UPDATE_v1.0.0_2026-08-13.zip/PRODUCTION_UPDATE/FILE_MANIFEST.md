# File manifest

68 files. 795.3 KB total. Four replace an existing file; the rest are
new. Checksums are the first 16 hex of SHA-256; the full set is in
`FILE_MANIFEST.sha256`, verifiable with `sha256sum -c`.

```bash
cd upload && sha256sum -c ../FILE_MANIFEST.sha256
```

| Path (relative to document root) | Action | Size | sha256 | Purpose |
|---|---|---|---|---|
| `.htaccess` | **REPLACE** | 4.9 KB | `0b7d6d544f21c179` | Apache config. Replaces v17.2; block 1 carries it verbatim |
| `404.html` | add | 4.5 KB | `3747ce314f7069b6` | Custom 404. Also served for an unpublished identifier route |
| `capabilities.json` | add | 6.8 KB | `cfee747f3b942b79` | Public projection of the capability register |
| `index.html` | **REPLACE** | 95.0 KB | `87af8b114d41e92a` | Landing page, patched. +66 / -0 lines vs deployed |
| `llms.txt` | add | 2.0 KB | `8af9fb58d1445d52` | AI-discovery index, generated from the register |
| `robots.txt` | **REPLACE** | 0.6 KB | `9c21323fa8dcbf54` | Crawler policy, rebound to the canonical host |
| `sitemap.xml` | **REPLACE** | 0.9 KB | `c2c2542d2286d70d` | Sitemap index over six child sitemaps |
| `assets/search-index.json` | add | 10.0 KB | `37b5dd4e9130eb45` | Build-time search index |
| `assets/css/nav-fit.min.css` | add | 1.8 KB | `ed987e81799bb1b7` | Navigation width fix, both surfaces |
| `assets/css/research.min.css` | add | 18.5 KB | `c55f2b9cf211e510` | Research design layer, additive to site.min.css |
| `assets/js/legal-deeplink.min.js` | add | 1.5 KB | `6828b7fcb09eee46` | Opens the existing legal modal from ?legal= |
| `assets/js/research-nav-i18n.min.js` | add | 1.7 KB | `04b8b9062cbdfeb0` | Adds nav.research to 18 dictionaries |
| `assets/js/research.min.js` | add | 6.1 KB | `960a137d11e18d8b` | Disclosure nav, contents highlighting, search |
| `feeds/.htaccess` | add | 0.1 KB | `014e3b8eb1c4705b` | Atom 1.0 feed, abstract only, never the body |
| `feeds/all.xml` | add | 1.8 KB | `3caea9407ea88393` | Atom 1.0 feed, abstract only, never the body |
| `feeds/institutional.xml` | add | 0.5 KB | `7d4f93a94f2e65f2` | Atom 1.0 feed, abstract only, never the body |
| `feeds/papers.xml` | add | 1.8 KB | `2a0518e60afe959c` | Atom 1.0 feed, abstract only, never the body |
| `feeds/technical-notes.xml` | add | 0.5 KB | `e50bcedf9845ee98` | Atom 1.0 feed, abstract only, never the body |
| `feeds/updates.xml` | add | 0.5 KB | `423344508100a27a` | Atom 1.0 feed, abstract only, never the body |
| `pdf/NEO-AI-R-009/v1.0.pdf` | add | 293.5 KB | `c59b7ed7853563ca` | The R-009 binary, 14 pages, A4 |
| `research/index.html` | add | 10.1 KB | `8ea734a177613096` | Page |
| `research/about/index.html` | add | 7.5 KB | `2aecbfa684ab47fb` | Page |
| `research/authors/index.html` | add | 5.1 KB | `c506437afc234018` | Page |
| `research/authors/mickael-mosse/index.html` | add | 5.9 KB | `7e0fe96420bc83d6` | Page |
| `research/capability-register/index.html` | add | 12.8 KB | `987abc6fe81f959a` | Page |
| `research/capability-register/assurance.eval-harness/index.html` | add | 6.6 KB | `8e685a540859dc6e` | Capability page, one per register key |
| `research/capability-register/brain/index.html` | add | 6.3 KB | `078d565b1938083a` | Capability page, one per register key |
| `research/capability-register/brain.cost-engine/index.html` | add | 6.5 KB | `757ed65b41356dc5` | Capability page, one per register key |
| `research/capability-register/brain.event-bus/index.html` | add | 6.3 KB | `ea45e634c0c2fdae` | Capability page, one per register key |
| `research/capability-register/brain.evidence-layer/index.html` | add | 6.6 KB | `f95c4ac21adadcc1` | Capability page, one per register key |
| `research/capability-register/brain.evidence-ledger/index.html` | add | 6.5 KB | `b2bc95f4954cac1b` | Capability page, one per register key |
| `research/capability-register/brain.governance/index.html` | add | 6.3 KB | `245053a990a00287` | Capability page, one per register key |
| `research/capability-register/brain.knowledge-graph/index.html` | add | 6.4 KB | `0822168c911e8e4e` | Capability page, one per register key |
| `research/capability-register/brain.memory/index.html` | add | 6.3 KB | `1b2274703d7ff313` | Capability page, one per register key |
| `research/capability-register/brain.router/index.html` | add | 6.3 KB | `dd9cdc5939ca8561` | Capability page, one per register key |
| `research/capability-register/brain.task-graph/index.html` | add | 6.3 KB | `640f45629a62b2ed` | Capability page, one per register key |
| `research/capability-register/brain.validation/index.html` | add | 6.3 KB | `29a07f2768715e53` | Capability page, one per register key |
| `research/capability-register/dataroom.backend/index.html` | add | 6.2 KB | `2e64a5a170017a36` | Capability page, one per register key |
| `research/capability-register/dataroom.frontend/index.html` | add | 6.2 KB | `d0bd3142c1c231ef` | Capability page, one per register key |
| `research/capability-register/deployment.cloud/index.html` | add | 6.1 KB | `7b5248369777f77a` | Capability page, one per register key |
| `research/capability-register/deployment.onprem/index.html` | add | 6.2 KB | `ef50c05dd04ed653` | Capability page, one per register key |
| `research/capability-register/deployment.vpc/index.html` | add | 6.1 KB | `337ddaae792ecc76` | Capability page, one per register key |
| `research/capability-register/foundation-model/index.html` | add | 6.5 KB | `3d1e209de98a1630` | Capability page, one per register key |
| `research/capability-register/lili/index.html` | add | 6.2 KB | `276a01dc9261ce2e` | Capability page, one per register key |
| `research/capability-register/mission-control/index.html` | add | 6.4 KB | `fd8ab3e0ff96d9dc` | Capability page, one per register key |
| `research/capability-register/mission.envelope/index.html` | add | 6.5 KB | `81cb8aa965c593c7` | Capability page, one per register key |
| `research/capability-register/neo-intelligence/index.html` | add | 6.4 KB | `0a404a436c95623e` | Capability page, one per register key |
| `research/capability-register/pilots/index.html` | add | 6.2 KB | `514de3f5c448c822` | Capability page, one per register key |
| `research/capability-register/public-website/index.html` | add | 6.1 KB | `534896a4581f0545` | Capability page, one per register key |
| `research/glossary/index.html` | add | 10.1 KB | `fff284d5cd592012` | Page |
| `research/institutional/index.html` | add | 5.7 KB | `e04a42ba8a352cff` | Page |
| `research/methodology/index.html` | add | 7.5 KB | `b37da00ac05764d2` | Page |
| `research/papers/index.html` | add | 6.2 KB | `713a08e12237a02c` | Page |
| `research/papers/model-intelligence-to-system-intelligence/index.html` | add | 70.9 KB | `f0820be169ca9be2` | Page |
| `research/roadmap/index.html` | add | 8.7 KB | `2f305c685391bd81` | Page |
| `research/technical-notes/index.html` | add | 5.6 KB | `0ad733dad5e81e52` | Page |
| `research/topics/multi-model/index.html` | add | 6.4 KB | `b819240bd589a075` | Topic hub, built only because a member resolves |
| `research/topics/system-intelligence/index.html` | add | 6.4 KB | `3cdd3034cb70e149` | Topic hub, built only because a member resolves |
| `research/updates/index.html` | add | 5.8 KB | `d25d2de9542641dc` | Page |
| `schema/capabilities-v1.json` | add | 1.5 KB | `3b1302c98d1905aa` | JSON Schema for the capability register |
| `schema/entities.jsonld` | add | 1.1 KB | `5a66919d0bc4ceb3` | Entity graph, referenced by @id from every page |
| `search/index.html` | add | 6.0 KB | `43b50588b874e5df` | Page |
| `sitemaps/capability.xml` | add | 4.2 KB | `c81fde652e21c1ba` | Child sitemap |
| `sitemaps/figures.xml` | add | 0.1 KB | `1214c52cace28c40` | Child sitemap |
| `sitemaps/glossary.xml` | add | 0.2 KB | `8b7ebcafe8cc3c00` | Child sitemap |
| `sitemaps/indexes.xml` | add | 2.0 KB | `0027070545feded9` | Child sitemap |
| `sitemaps/platform.xml` | add | 0.2 KB | `e389ac9a37e14906` | Child sitemap |
| `sitemaps/publications.xml` | add | 0.3 KB | `bbd4138c10ec824c` | Child sitemap |

## Files that REPLACE a deployed file

| Path | Back this up first |
|---|---|
| `index.html` | yes — the only file whose loss is not recoverable from this package |
| `robots.txt` | yes |
| `sitemap.xml` | yes |
| `.htaccess` | yes — and diff it if you have edited it since v17.2 |

Everything else is additive: deleting the added tree returns the server to its
pre-deployment state exactly.

## Deployed files this package does NOT touch

`assets/css/site.min.css` · `assets/favicon.svg` · `assets/relay.php` ·
`assets/js/three.min.js` · `vendor.min.js` · `app-i18n.min.js` ·
`app-runtime.min.js` · `app-sections.min.js` · `app-engine.min.js` ·
`app-universe.min.js`
