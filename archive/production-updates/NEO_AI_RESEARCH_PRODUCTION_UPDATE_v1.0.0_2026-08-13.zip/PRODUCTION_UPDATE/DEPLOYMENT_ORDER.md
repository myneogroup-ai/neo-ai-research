# Deployment order

Three preconditions, then eleven steps. Steps 1–7 put the corpus live and
**unlinked** — reversible in seconds. Step 8 is the publication moment. Step 9
onward is the legacy-host decision and is the only part that is not fully
reversible.

Total hands-on time: about 20 minutes. Do not compress steps 5 and 8.

---

## Precondition P1 — you are patching the file this was built against

```bash
sha256sum <docroot>/index.html
```

Must print `836bbfbaec245e3ce13449f8595837ae77740cf60fcc24b410ba72db68dc1ee6`.

**If it differs**, the deployed `index.html` is not the v17.2 file in
`build/source/index.html`. Do not upload the supplied `index.html`. Instead:
copy the real deployed file to `build/source/index.html`, run
`python3 build/patch_index.py` (it will fail on the pinned hash — clear
`EXPECTED_SHA` first), and confirm all six anchors report `applied`. If any
anchor is not found exactly once, apply that change by hand from
`MODIFICATIONS.md` and re-verify.

## Precondition P2 — the document root is the subdomain root

Every path in the new tree is root-relative. Confirm the subdomain serves from
its own document root and not from a subdirectory:

```bash
curl -sI https://neoai.myneogroup.com/robots.txt | head -1     # 200
curl -s  https://neoai.myneogroup.com/robots.txt | head -2
```

If that returns the content of `neoai/robots.txt`, the docroot is the `neoai`
folder and **P2 holds**. (Verified true on 13 August 2026.)

**If P2 does not hold** — if the subdomain is an alias into
`public_html/neoai/` such that the site answers at
`https://neoai.myneogroup.com/neoai/…` — stop. Every research page will render
unstyled and every internal link will 404. The fix is one line: set
`HOST` and the asset prefix in `build/neo_research_build.py` and rebuild. Ask
before doing it; it changes every canonical URL in the corpus and canonical URLs
are frozen at first publication.

---

## Precondition P3 — your FTP client shows hidden files

Two files in this package are dotfiles: `.htaccess` at the root and
`feeds/.htaccess`. Many FTP and SFTP clients hide them by default and will skip
them without reporting anything. Turn hidden files on before you start.

---

## Step 1 — back up

```bash
cp -a public_html/ public_html.bak-$(date +%Y%m%d-%H%M)/
```

Rollback depends on this and on nothing else. `ROLLBACK.md` assumes it exists.

## Step 2 — `.htaccess` first, alone

Upload `upload/.htaccess` **and nothing else**. Then:

```bash
curl -sI https://neoai.myneogroup.com/ | head -1        # 200, not 500
```

A syntax error here returns 500 for the whole site. Doing it alone means a 500
has exactly one possible cause. If you get one, restore the backed-up
`.htaccess` and read `MODIFICATIONS.md` M-07: the likely cause is a missing
`mod_rewrite`, which block 4 needs.

```bash
apachectl -M 2>/dev/null | grep -E 'rewrite|headers|expires|deflate'
```

## Step 3 — assets

Upload `upload/assets/css/research.min.css`, `upload/assets/css/nav-fit.min.css`,
`upload/assets/js/research.min.js`, `upload/assets/js/research-nav-i18n.min.js`,
`upload/assets/js/legal-deeplink.min.js`, `upload/assets/search-index.json`.

These are additive. Nothing references them yet, so nothing can break.

## Step 4 — the research tree, the PDF, the 404

Upload `upload/research/`, `upload/search/`, `upload/pdf/`, `upload/schema/`,
`upload/404.html`.

Still unreferenced from anywhere the public can see. **This is Phase A: content
live and unlinked.**

## Step 5 — verify in production what you verified in staging

Do not skip this. The differences that matter are the ones staging cannot
reproduce.

```bash
curl -sI https://neoai.myneogroup.com/research/                        # 200
curl -sI https://neoai.myneogroup.com/research/papers/model-intelligence-to-system-intelligence/  # 200
curl -sI https://neoai.myneogroup.com/research/capability-register/brain.router/                  # 200
curl -sI https://neoai.myneogroup.com/pdf/NEO-AI-R-009/v1.0.pdf        # 200, X-Robots-Tag present
curl -sI https://neoai.myneogroup.com/id/NEO-AI-R-009                  # 302 -> the canonical
curl -sI https://neoai.myneogroup.com/id/NEO-AI-R-001                  # 404, and that is correct
curl -sI https://neoai.myneogroup.com/research/papers                  # 301 -> trailing slash
```

Open `/research/papers/model-intelligence-to-system-intelligence/` in a browser.
Check: the page is styled, the contents list works, the capability chips show
S4/S5, no console error.

**A capability key rendering with the wrong status, or an unstyled page, stops
the deployment here.**

## Step 6 — discovery files

Upload `upload/robots.txt`, `upload/sitemap.xml`, `upload/sitemaps/`,
`upload/feeds/` (**including `feeds/.htaccess`**), `upload/llms.txt`,
`upload/capabilities.json`.

```bash
curl -s https://neoai.myneogroup.com/robots.txt | grep Sitemap
curl -s https://neoai.myneogroup.com/sitemap.xml | grep -c '<loc>'   # 6
curl -s https://neoai.myneogroup.com/llms.txt | head -1
curl -sI https://neoai.myneogroup.com/feeds/all.xml | grep -i content-type
# must be application/atom+xml — if it is application/xml, feeds/.htaccess
# was skipped by your FTP client
```

Do **not** submit the sitemap yet. That happens at step 8.

## Step 7 — the landing page

Upload `upload/index.html`.

```bash
curl -s https://neoai.myneogroup.com/ | grep -c 'rel="canonical"'    # 1
```

Open the homepage. Check, in this order:

1. The hero, the WebGL sequence and the scroll choreography behave exactly as
   before. **The typography will have changed** — that is M-08 and it is
   expected. If anything else moved, stop.
2. The language selector still lists eighteen languages and still switches.
3. Switch to French: the nav reads **Recherche**. Switch to Arabic: the layout
   is still RTL and the nav reads **الأبحاث**.
4. Click Privacy in the footer: the legal modal opens as before.
5. Visit `/?legal=privacy`: the modal opens and the URL cleans itself to `/`.
6. No console error.

**Research is now in the navigation. This is Phase B, the publication moment.**

## Step 8 — submit

Google Search Console and Bing Webmaster Tools: submit
`https://neoai.myneogroup.com/sitemap.xml`.

Request indexing for `/research/` and for the R-009 canonical.

Then run `QA_CHECKLIST.md` in full.

## Step 9 — the legacy subpath. Decide, do not drift.

If `https://myneogroup.com/neoai/` still serves the site, you now have the same
content on two hosts and the subdomain has no way to claim it — `.htaccess`
inside the subdomain docroot cannot speak for the WordPress root.

Do one of these, in the **WordPress root**, not here:

```apache
# preferred: retire the subpath
RewriteRule ^neoai/?$ https://neoai.myneogroup.com/ [R=301,L]
```

or, if it must stay reachable, add to the subpath's `<head>`:

```html
<link rel="canonical" href="https://neoai.myneogroup.com/">
```

Also add to `https://myneogroup.com/robots.txt`:

```
Sitemap: https://neoai.myneogroup.com/sitemap.xml
```

See `PREEXISTING_DEFECTS.md` D-1 and D-2.

## Step 10 — observation

| Day | Measure | Roll back if |
|---|---|---|
| continuous | server errors | above 0.5% |
| continuous | redirect chain or loop | any occurrence |
| continuous | a capability described as deployed that is not | any occurrence |
| 7 | crawl errors in Search Console | any 404 from a submitted sitemap |
| 14 | indexed URLs vs baseline | below 50% |
| 21 | organic entrances vs the 28-day baseline | below 60% |

The landing page's own traffic is the baseline that matters. The research tree
has no history and cannot regress.

## Step 11 — record

Fill the rehearsal and event tables in `ROLLBACK.md`. A rollback plan that has
never been executed is a document, not a capability — rehearse the Phase B
revert (delete one line from `index.html`) once, and time it.

---

## What deploys together and must not be split

| Group | Why |
|---|---|
| M-01 + the research tree | Research pages reference five `@id` nodes that M-01 defines. Deploying pages without M-01 leaves dangling references |
| M-02 + M-03a | Without the dictionary extension the nav link is untranslated in seventeen languages |
| M-02 + M-04 | Nav and footer should not disagree about whether Research exists |
| M-08 on both surfaces | Applying the font restoration to one surface and not the other gives one site two typographies |
| M-05 + M-06 | robots and sitemap must agree about the canonical host |
