# Changelog

## research-delta-1.0.0 — 13 August 2026

Integrates the NEO AI Research Program into the live public website. Built
against deployed `v17.2` and the frozen research repository.

### Added — routes

- `/research/` library index, with the claim-class legend and the held and
  registered tables
- `/research/papers/`, `/research/institutional/`, `/research/technical-notes/`
  category indexes
- `/research/papers/model-intelligence-to-system-intelligence/` — **NEO-AI-R-009**,
  the only publishable full text in the corpus
- `/research/capability-register/` plus **24** capability pages, one per key
- `/research/glossary/` — 39 terms, definitions explicitly not yet published
- `/research/methodology/`, `/research/about/`, `/research/authors/`,
  `/research/authors/mickael-mosse/`, `/research/updates/`, `/research/roadmap/`
- `/research/topics/system-intelligence/`, `/research/topics/multi-model/`
- `/search/` — client-side, `noindex, follow`
- `/404.html` — styled, and it explains the unpublished-identifier case
- `/pdf/NEO-AI-R-009/v1.0.pdf` — 14 pages, A4, generated from the same reduced
  source as the HTML

### Added — discovery

- `sitemap.xml` as an index over six child sitemaps
- five Atom feeds; entry `id` is the identifier route, never the canonical
- `llms.txt` — the intro blockquote carries all four claim classes
- `capabilities.json` — public projection of the register
- `schema/entities.jsonld`, `schema/capabilities-v1.json`
- `assets/search-index.json` — 72 documents, 10 KB

### Added — assets

- `assets/css/research.min.css` — additive to `site.min.css`, scoped to
  `body.research`
- `assets/css/nav-fit.min.css` — navigation width fix, both surfaces
- `assets/js/research.min.js` — disclosure nav, contents highlighting, search
- `assets/js/research-nav-i18n.min.js` — `nav.research` in 18 languages
- `assets/js/legal-deeplink.min.js` — opens the existing legal modal from
  `?legal=`

### Changed

- `index.html` — six insertions, **+66 / −0 lines**. Canonical, robots, social
  cards, entity graph; Research in the nav and the footer; two script tags; the
  webfont stylesheet restored
- `robots.txt` — rebound to the canonical host; Bytespider denied, CCBot
  allowed, filter parameters disallowed
- `sitemap.xml` — was one URL on the wrong host; now a sitemap index
- `.htaccess` — every v17.2 directive carried forward in block 1; six blocks
  added

### Fixed — defects older than this release

- **D-2** `robots.txt` and `sitemap.xml` declared `myneogroup.com/neoai/` while
  serving from the subdomain. A crawler was handed a map of a different host
- **D-3** the three webfonts were requested in CSS and never loaded; the
  stylesheet link was lost when the single-file preview was split into the
  deployed package. Restored byte-identically from the preview
- **D-5** no canonical, no robots directive, no OpenGraph, no structured data on
  the homepage
- **D-6** the navigation pill measured 1278px and its links did not collapse
  until 1080px, so it was silently clipped between 1081 and 1278px. The
  nine-link bar is now narrower than the deployed eight-link bar

### Fixed — defects in the frozen corpus artefacts

- `gen_seo.py` hardcoded all five topic hubs into `indexes.xml`; three of them
  gather only unpublished documents and would have shipped as empty indexed
  pages. Hub membership is now derived, and the build reports what it skipped
- `gen_seo.py` declared twelve platform routes; eleven do not exist.
  `platform.xml` now carries the homepage alone
- `schema/entities.jsonld` carried the literal placeholders
  `ORCID_TO_BE_REGISTERED_BEFORE_FIRST_PUBLICATION` and
  `REAL_CONTROLLED_RECIPROCAL_PROFILES_ONLY`. Both fields are omitted from the
  served graph
- seven CLS-13 internal references in the R-009 text and six in the capability
  register were removed by the documented reduction passes. `REDUCTIONS.md`

### Not included, deliberately

- The five Wave 1 texts whose public editions are not cleared, and the three
  Wave 1b papers. They are named, without dates, on the roadmap
- Glossary definitions — the term set is final, the text is not published
- The eleven platform and company routes
- `hreflang` and per-language URLs — `PREEXISTING_DEFECTS.md` D-4
- `og:image` — no card exists. Specified in `IMAGES.md` §3
- Any figure — R-009 states that its figure is specified and not drawn
- A Content-Security-Policy — the landing page carries inline script and style
  and a CSP added without auditing them would break it
