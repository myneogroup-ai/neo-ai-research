# Navigation

## 1. Primary navigation

One link is added to the landing page. Research pages carry their own copy of
the same bar, plus a disclosure menu the landing page does not have.

| Position | Label | Target | Where |
|---|---|---|---|
| 1–7 | Going Public, The Engine, Performance, Capabilities, Mission Control, Industries, NEO Intelligence | `#golive` … `#intel` on the landing page; `/#golive` … from a research page | both |
| **8** | **Research** | `/research/` | **added** |
| 9 | Investors | `#investors` / `/#investors` | both |
| — | Language selector, 18 languages | — | landing page only |
| — | Request Early Access | `#waitlist` / `/#waitlist` | both |

**Research sits before Investors.** The corpus precedes the commercial ask in
reading order, and the CTA stays last.

**The language selector is absent from research pages, deliberately.** The
corpus is English-only at the root and `docs/06_CANONICAL_URL_MAP.md` §4 settles
that there is no `/en/` prefix, now or ever. A selector that offered eighteen
languages and delivered one would be a false affordance. A future language wave
adds `/<iso-639-1>/` mirroring the English tree, at which point the selector
returns and means something.

## 2. Breakpoints

| Width | Landing page | Research page |
|---|---|---|
| ≥ 1401px | 9 links inline | 9 links inline |
| 1081–1400px | 9 links, tightened by `nav-fit.min.css`; the row scrolls inside the pill if it must | 9 links, tightened; no scroll needed |
| ≤ 1080px | links hidden, **no replacement** (pre-existing) | **disclosure menu** |

Measured at twenty widths from 360 to 1920px: no viewport overflow on either
surface. `QA_EVIDENCE/nav-widths.txt`.

The landing page keeps its current below-1080px behaviour. Giving it a menu is a
design change rather than a defect fix, and it is recorded in
`PREEXISTING_DEFECTS.md` D-6 as worth scheduling.

## 3. The disclosure menu, research pages only

Scoped to `body.research`, so the landing page is untouched.

- Button reports `aria-expanded` and `aria-controls="rMenu"`
- Escape closes it and returns focus to the button
- A click outside closes it
- Tap targets are 44px
- Links are in the DOM whether or not JavaScript runs; only the toggle needs it

## 4. Breadcrumb

Every route except `/404.html` renders a trail, and the `BreadcrumbList` in
JSON-LD is emitted **only** where the trail is rendered — a breadcrumb that
exists only in markup is prohibited, and `verify_delta.py` check SD-BC enforces
it.

| Route class | Trail |
|---|---|
| `/research/` | Research |
| `/research/papers/` | Research / Research papers |
| a publication | Research / Research papers / *exact title* |
| `/research/capability-register/<key>/` | Research / Capability Register / *capability name* |
| `/research/topics/<slug>/` | Research / Topics / *hub name* |
| everything else | Research / *page* |

"Topics" in a hub trail is not a link: `/research/topics/` is not a route. It
carries no `item` in the markup either, so the structured data does not assert a
page that does not exist.

## 5. Footer

The landing page footer gains one link, Research, in the same row as Investors,
Privacy, Terms and Cookies. It uses the same `data-i18n` key as the nav, so one
dictionary entry serves both.

Research pages carry their own footer: Research, Methodology, Capability
Register, Glossary, Updates, Atom feed, then Privacy, Terms, Cookies. The legal
links point at `/?legal=privacy|terms|cookies`, which opens the existing modal on
the landing page — the legal text is not duplicated, so it cannot drift.

Every research footer also carries the three entity link elements the structured
data model requires:

```html
<link rel="me"        href="https://mickaelmosse.ai/about/">
<link rel="author"    href="https://mickaelmosse.ai/about/">
<link rel="publisher" href="https://neoai.myneogroup.com/research/about/">
```

A person writes; an organisation publishes.

## 6. In-corpus navigation

Beyond the chrome, a reader moves through the corpus by:

- the **contents list** on a publication, two columns above 760px, with the
  current section highlighted
- **claim chips**, where every `[D]` links to the capability it names
- **first-occurrence glossary links**, applied by the build from
  `registers/vocabulary.json`, never by an author
- **typed relations** at the foot of a publication, linked where they resolve
  and rendered as stated text where they do not
- **topic hubs**, which list only what resolves
- the **roadmap**, which is where an unresolvable identifier honestly leads
- **search** at `/search/`, `noindex, follow`

## 7. Translation of the new link

`data-i18n="nav.research"`, resolved by `research-nav-i18n.min.js`:

| | | | | | |
|---|---|---|---|---|---|
| en Research | fr Recherche | it Ricerca | es Investigación | pt Pesquisa | ru Исследования |
| zh 研究 | ja リサーチ | ko 리서치 | ar الأبحاث | de Forschung | hi अनुसंधान |
| tr Araştırma | th งานวิจัย | vi Nghiên cứu | bn গবেষণা | id Riset | ur تحقیق |

If that file is absent or loads in the wrong order, `applyLang()` finds no key,
leaves the markup text alone, and the link reads "Research" everywhere.
Degraded, never broken.
