# Rollback

**Standing authority. Signed in advance, executed on trigger, reported
afterwards.** A rollback that needs an approval is a rollback that happens hours
late, at night, by somebody who cannot reach the person with authority.

The executing officer rolls back on any trigger below and informs afterwards.
That order is deliberate.

---

## Triggers — measured, not judged

Any single trigger is sufficient. None needs a second opinion.

| # | Trigger | Threshold | Action |
|---|---|---|---|
| **T1** | A capability described as deployed that is not | **any occurrence** | Withdraw the page immediately, then correct |
| **T2** | Classified or internal material on a public page | **any occurrence** | Withdraw immediately, then full rollback if the source is unclear |
| T3 | Server errors | above 0.5% | Roll back |
| T4 | Redirect chain or loop | any occurrence | Fix within 30 minutes or roll back |
| T5 | The landing page's hero, WebGL or form regressed | any occurrence | Roll back `index.html` only |
| T6 | Indexed URLs at day 14 | below 50% of baseline | Roll back |
| T7 | Organic entrances at day 21 | below 60% of the 28-day baseline | Roll back |
| T8 | A pinned version redirected forward | any occurrence | Roll back the whole redirect block |

**T1 and T2 have no tolerance band.** T2 cannot be undone by removing the page,
because the page has already been read; the rollback limits further exposure and
the disclosure is handled separately.

T8 cannot fire today — no pinned archive exists yet, because no publication has
taken a MAJOR version. It is listed so it is not forgotten when one does.

---

## Reversal, by how far you got

Choose the smallest one that addresses the trigger. Do not reach for the full
rollback when one line will do.

### Level 1 — unlink Research. **30 seconds. Fully reversible.**

Delete one line from `index.html`:

```html
    <a href="/research/" data-i18n="nav.research">Research</a>
```

and the matching footer line. The site returns to Phase A: every research URL
stays live and citable, and nothing in the navigation points at it. **This is
the correct response to almost every content problem**, because it stops
discovery without breaking a single URL anyone may already have cited.

### Level 2 — restore the landing page. **2 minutes.**

```bash
cp public_html.bak-*/index.html public_html/index.html
```

Reverses M-01, M-02, M-03, M-04 and M-08 together. The research tree stays live
and self-contained; it loses only the five `@id` targets M-01 defined, which
degrades the entity graph and breaks nothing a reader sees.

Use this for T5.

### Level 3 — withdraw one page. **2 minutes.** For T1 and T2.

```bash
rm public_html/research/papers/<slug>/index.html
```

then add to `.htaccess`, above block 4:

```apache
Redirect 410 /research/papers/<slug>/
```

**410, not 404.** The withdrawal is deliberate and 410 says so; 404 says the
server does not know. Record the withdrawal in the register before doing
anything else.

### Level 4 — remove the routing block. **5 minutes.**

```bash
cp public_html.bak-*/.htaccess public_html/.htaccess
```

Identifier routes stop resolving; every canonical URL still serves. Use this if
a rewrite rule is looping and cannot be fixed in 30 minutes.

### Level 5 — full rollback. **10 minutes.**

```bash
rm -rf public_html/research public_html/search public_html/pdf \
       public_html/sitemaps public_html/feeds public_html/schema \
       public_html/llms.txt public_html/capabilities.json public_html/404.html \
       public_html/assets/css/research.min.css \
       public_html/assets/css/nav-fit.min.css \
       public_html/assets/js/research.min.js \
       public_html/assets/js/research-nav-i18n.min.js \
       public_html/assets/js/legal-deeplink.min.js \
       public_html/assets/search-index.json
cp public_html.bak-*/index.html   public_html/index.html
cp public_html.bak-*/robots.txt   public_html/robots.txt
cp public_html.bak-*/sitemap.xml  public_html/sitemap.xml
cp public_html.bak-*/.htaccess    public_html/.htaccess
```

The server is byte-identical to its pre-deployment state. Then in Search
Console, remove the submitted sitemap.

**Note.** Restoring `robots.txt` and `sitemap.xml` restores two files that were
already wrong before this release (`PREEXISTING_DEFECTS.md` D-2). If the
rollback is for a research-side problem, prefer to keep the corrected versions
and roll back everything else.

---

## What no rollback repairs

**An external citation of a new canonical URL, made in the window.** It cannot
be recalled. This is why the identifier route always issues a 302 and never a
301, why slugs are frozen at first publication, and why a version-pinned archive
is never redirected forward once one exists.

It is also why Level 1 is the preferred response: unlinking stops discovery
without invalidating anything already cited.

---

## Verify the reversal

A rollback that leaves the site half-reverted has not fixed the thing that
mattered.

- [ ] `curl -sI /` returns 200
- [ ] The landing page renders and the form still submits
- [ ] No redirect chain, no loop
- [ ] A withdrawn page returns **410**, not 404
- [ ] The register records the withdrawal
- [ ] `sitemap.xml` and `robots.txt` agree with each other about the host

---

## Rehearsal — required before publication

| | |
|---|---|
| Rehearsed by | |
| Date | |
| Level rehearsed | Level 1 / Level 2 / Level 5 |
| Time taken | ______ minutes |
| Result | under 30 minutes / **over — hold publication** |

## Event record

Completed after the fact, never in advance.

| Date and time | Trigger | Level | Time to complete | Executed by | Founder informed |
|---|---|---|---|---|---|
| | | | | | |
