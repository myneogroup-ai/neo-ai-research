# Images

## 1. This release ships no new image, and that is a decision

`sitemaps/figures.xml` is present and **empty**. The file exists so the sitemap
index does not point at a 404. An empty sitemap is honest.

R-009 states it directly, in its own back matter: *"Related Figures — None in
Wave 1. A figure for the eight operations of section 3 is specified and not
drawn."*

Inventing a diagram to fill the gap would put an unreviewed visual assertion
into a corpus whose entire argument is about not asserting more than it can
support. A figure in this corpus is a specified artefact that regenerates from
its specification and passes the figure standard; it is not decoration.

## 2. Images the new pages use

| Asset | Source | Status |
|---|---|---|
| `assets/favicon.svg` | already deployed | reused, not re-uploaded |
| Logo in the research nav | `favicon.svg` at 18×18 plus the word "NEO AI" in Space Grotesk | no new file |

The landing page embeds its logo as an inline base64 PNG. Research pages do not
reuse it: a ~24 KB data URI repeated across 41 documents costs about 1 MB of
transferred HTML for one wordmark. The SVG favicon plus live text is 1.2 KB
once, cached, sharper at every density, selectable, translatable and
screen-reader legible.

## 3. Social sharing — the one real gap

M-01 adds `og:title`, `og:description`, `og:url` and `twitter:card`. It does
**not** add `og:image`, because no image exists at the right dimensions.

**Consequence.** A link shared to LinkedIn, Slack, X or WhatsApp renders as a
text card with no picture. That is materially better than today, where it
renders as a bare URL, and materially worse than it could be.

### Required, to close it

| File | Size | Format | Location | Purpose |
|---|---|---|---|---|
| `og-default.png` | 1200 × 630 | PNG, < 300 KB | `/assets/og/` | landing page and any page without a specific card |
| `og-research.png` | 1200 × 630 | PNG, < 300 KB | `/assets/og/` | `/research/` and the category indexes |
| `og-NEO-AI-R-009.png` | 1200 × 630 | PNG, < 300 KB | `/assets/og/` | the publication |

**Specification, so they can be produced without another conversation.**

- Background `#020208`. Optional radial glow in `#063cfc` at 8% opacity, upper
  left, matching the site's halo treatment.
- Wordmark **NEO AI** in Space Grotesk Medium, 44px, `#f4f6ff`, 64px from the
  left and top edges.
- Rule beneath the wordmark: 2px, `#063cfc`, 120px wide.
- Title in Space Grotesk Medium, 62px, `#f4f6ff`, line-height 1.12, maximum
  three lines, left aligned, 64px margins, optically centred vertically.
- Kicker above the title in JetBrains Mono, 20px, letter-spacing 2.4px,
  uppercase, `#69e6ff` — "RESEARCH PAPER", "NEO AI RESEARCH", or nothing.
- Bottom-left, JetBrains Mono 20px `#6d7691`: `neoai.myneogroup.com`.
- **No status token, no capability status, no claim class, no date.** A card is
  quoted without its qualifiers, and a status token that survives into a
  screenshot without its context is exactly the failure mode the corpus is
  built to avoid. This is a deliberate exclusion, not an omission.
- Safe area: keep all content 64px from every edge. Cards are cropped to 1.91:1
  by some clients and to a square by others.

### Once they exist

Add to the head of the relevant page:

```html
<meta property="og:image" content="https://neoai.myneogroup.com/assets/og/og-research.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="NEO AI Research">
<meta name="twitter:image" content="https://neoai.myneogroup.com/assets/og/og-research.png">
```

and change `twitter:card` from `summary` to `summary_large_image` on research
pages. In `build/neo_research_build.py` this is four lines in the `page()`
template; the landing page is one insertion in `patch_index.py`.

**`og:image:alt` is not optional.** It is the only accessible description a
shared card carries.

## 4. Figures, when the first one is drawn

The route exists and is reserved: `/research/figures/<PUBID>-<n>/`. The
permalink page renders the figure, its caption, its specification reference and
the publication it belongs to. `sitemaps/figures.xml` then stops being empty.

Requirements at that point: SVG for anything diagrammatic, generated from its
specification rather than drawn by hand; alt text that states what the figure
shows rather than that a figure exists; a caption that survives being read
alone; and legible rendering at 320px wide, because a figure that needs a
desktop is a figure most readers will not read.
