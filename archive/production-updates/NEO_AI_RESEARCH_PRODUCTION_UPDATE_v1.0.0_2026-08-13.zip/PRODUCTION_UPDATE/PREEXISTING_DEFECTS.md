# Pre-existing defects on the live site

Seven defects found while auditing the deployed build. **None was introduced by
this release.** Four are fixed here because the delta touches the same file
anyway. Three need a decision that is outside the scope of a research release.

They are reported because a package that silently fixes some and silently leaves
others is impossible to review.

| # | Defect | Severity | Status in this release |
|---|---|---|---|
| D-1 | Two hosts serve the same site, neither claims canonical | **Critical** | Partly fixed. Needs a WordPress-root change |
| D-2 | `robots.txt` and `sitemap.xml` point at the wrong host | **Critical** | **Fixed** (M-05, M-06) |
| D-3 | Webfonts are requested in CSS and never loaded | **High** | **Fixed** (M-08) |
| D-4 | Eighteen languages, one URL, zero indexable translations | **High** | Not fixed. Needs a decision |
| D-5 | No structured data, no canonical, no social cards | **High** | **Fixed** (M-01) |
| D-6 | Navigation pill wider than the viewport at 1081–1278px | Medium | **Fixed** (`nav-fit.min.css`) |
| D-7 | Landing page has no `<main>` landmark and no skip link | Low | Not fixed. Bundle with D-6 |

---

## D-1 · Two hosts, no canonical owner — **Critical**

**Evidence.** The v17.2 deployment runbook targets
`https://myneogroup.com/neoai/`. The site now answers at
`https://neoai.myneogroup.com/`. The deployed `robots.txt` and `sitemap.xml`
still name the subpath, which is strong evidence the subpath was live and may
still be.

**Consequence.** If both resolve, the same document is served at two addresses
with no `rel=canonical` on either. Search engines pick a winner on their own
signals, and the loser's accumulated authority is stranded. Worse for this
programme specifically: the frozen corpus binds **every** canonical URL,
identifier route and structured-data `@id` to
`neoai.myneogroup.com`. If a search engine has already chosen the subpath as
canonical, the research corpus publishes onto a host the index treats as a
duplicate.

**Fixed here.** M-01 adds `rel=canonical` to the subdomain homepage. Every new
research page is self-canonical on the subdomain.

**Not fixed here, and it must be.** The subpath is on a different host under
WordPress. `.htaccess` inside the subdomain document root cannot speak for it.
`DEPLOYMENT_ORDER.md` step 9 gives the two acceptable resolutions. **Do this
within the same maintenance window, not later** — publishing a corpus of
permanent citable URLs onto a contested host is the one mistake here that gets
more expensive every day.

---

## D-2 · robots and sitemap name the wrong host — **Critical. Fixed.**

**Evidence, live on 13 August 2026:**

```
GET https://neoai.myneogroup.com/robots.txt
  Sitemap: https://myneogroup.com/neoai/sitemap.xml

GET https://neoai.myneogroup.com/sitemap.xml
  <loc>https://myneogroup.com/neoai/</loc>     ← the only URL in the file
```

The sitemap served from the subdomain declares exactly one URL and it is on a
different host. A crawler arriving at the subdomain is handed a map of somewhere
else.

**Fixed** by M-05 and M-06. Still required at the WordPress root:
`Sitemap: https://neoai.myneogroup.com/sitemap.xml`.

---

## D-3 · The webfonts have never loaded — **High. Fixed.**

`site.min.css` specifies `Space Grotesk`, `Inter` and `JetBrains Mono`
throughout. `index.html` carries the two `preconnect` hints to Google Fonts and
**no stylesheet link**. There is no `@import` and no `@font-face` anywhere in
the package. The three families have therefore never rendered; the site has been
drawing in system fallbacks since v17.2 shipped.

`preview/NEO_AI_single_file_preview.html`, from the same delivery, **does**
carry the link. The link was lost when the preview was split into the deployed
package; the orphaned preconnects are the fingerprint.

**Fixed** by M-08, restoring the byte-identical URL from the preview. Read the
warning in `MODIFICATIONS.md` M-08 first: this visibly changes the landing
page's typography and needs its own QA pass.

**Also worth knowing.** `site.min.css` uses `font-family:var(--disp)` in one
rule and `--disp` is never defined in `:root`. That declaration is invalid and
the element falls back to inherited. One rule, cosmetic, not fixed here.

---

## D-4 · Eighteen languages, one URL — **High. Not fixed. Needs a decision.**

The language selector swaps `data-i18n` text nodes in place and writes
`document.documentElement.lang`. It creates no URL. `/fr/`, `?lang=fr` and
`#fr` do not exist.

**Consequences.**

- No translated page can be indexed. Eighteen dictionaries of translated copy
  have zero search surface.
- A French reader cannot share the French page; the link opens in the visitor's
  own last-used language, from `localStorage`.
- `hreflang` cannot be emitted. Every alternate would point at the same URL, and
  reciprocity could not be satisfied. This is why M-01 adds no `hreflang`.

**Not fixed here, deliberately.** It needs per-language routes, which is a
structural change to the landing page and out of scope for a research delta.
The corpus itself is unaffected: `docs/06_CANONICAL_URL_MAP.md` §4 settles that
English lives at the root with no `/en/` prefix, and reserves `/<iso-639-1>/`
for a future language wave. The research tree is English-only by design, and
adding a language later requires no migration and breaks no citation.

**Recommendation.** Treat it as its own release: pre-render the eighteen
variants to `/<code>/`, keep the client-side switcher as a redirect, emit
reciprocal `hreflang` with `x-default` on the English root.

---

## D-5 · No structured data, no canonical, no social cards — **High. Fixed.**

The deployed head is a title, a description and a viewport tag. No
`rel=canonical`, no robots directive, no OpenGraph, no Twitter card, no JSON-LD.
A link shared to Slack, LinkedIn or WhatsApp renders as a bare URL.

**Fixed** by M-01. Every property added corresponds to something the page
already renders; no `offers`, no rating, no interaction statistic.

---

## D-6 · The navigation pill is wider than the viewport at 1081–1278px — **Medium. Fixed.**

`.nav` is `position:fixed; left:50%; transform:translateX(-50%)` with no width
bound, so it sizes to content: **1278px** with the eight deployed links.
`.nav .links` does not collapse until 1080px. Between 1081px and 1278px the pill
overhangs the viewport and is clipped by `body{overflow-x:hidden}` — silently,
with no scrollbar. At a 1100px viewport it overhangs by 89px, 44px cut from each
end, taking part of the logo and part of the CTA with it.

Measured on the unmodified v17.2 build. Full table in
`QA_EVIDENCE/nav-widths.txt`, section A.

**Fixed** by `assets/css/nav-fit.min.css`, which also had to exist because this
release adds a ninth link. After the fix, no viewport overflow at any of twenty
widths from 360 to 1920px, and the nine-link bar at 1280px (1207px) is narrower
than the deployed eight-link bar (1278px).

**Related, not fixed.** Below 1080px the landing page hides its navigation links
and offers no replacement — no menu button, no drawer. On a phone the only
navigation is the logo and the CTA. Research pages solve this for themselves
with a disclosure menu scoped to `.research`; the landing page keeps its current
behaviour, because giving it a menu is a design change rather than a defect fix.
Worth scheduling.

---

## D-7 · The landing page has no `<main>` landmark and no skip link — Low. Not fixed.

`index.html` goes from `<nav class="nav">` straight into content with no
`<main>` element and no skip link. A screen-reader or keyboard user has no way
to bypass the nine navigation links, and assistive technology has no primary
landmark to jump to.

**Not fixed here.** Wrapping the landing page's content in `<main>` means
touching its section structure, which is a change to a regression-locked
document and carries real risk against the WebGL and scroll choreography that
depend on the current DOM. A skip link alone would be a two-line addition and is
worth doing, but it belongs with the `<main>` element rather than on its own.

Every research page has both: a visible-on-focus skip link and
`<main id="main">`. `verify_delta.py` checks A11Y-01 and STR-03 enforce it for
the 41 new routes and explicitly exempt `/`.

**Recommendation.** Bundle with the below-1080px navigation menu in D-6 as one
small landing-page accessibility release, with its own visual QA pass.

---

## Not defects, recorded so they are not re-investigated

- **`X-Frame-Options` and `Referrer-Policy` were absent.** Added in `.htaccess`
  block 3. No Content-Security-Policy: the landing page carries an inline
  configuration script and an inline `<style>`, and a CSP added without auditing
  those would break it.
- **`assets/relay.php` is untouched.** The Early-Access form and its rate
  limiting, honeypot and CORS lock are outside this release entirely.
- **The Data Room is untouched.** No route, robots rule or sitemap entry in this
  package refers to it.
