# Reductions applied at build time

The frozen corpus is an internal artefact. Two mechanical reduction passes run
when the public pages are built, and both are recorded here so the Program can
audit exactly what the build changed against the frozen source.

**A reduction never weakens or strengthens a claim.** It removes the name of an
internal instrument, gate, path or audit finding and leaves the reader-facing
statement intact. Where the internal reference *is* the statement, the statement
is rewritten to say the same thing in reader-facing terms.

These are the edits that `scripts/known_deferrals.json` records as CLS-13
findings cleared at execution steps 8, 14 and 15. Applying them at build time
means the public HTML is correct today; it does **not** clear the deferrals in
the corpus repository, and it does not make the corpus releasable. See
`AUDIT_CTO_FINAL.md` §4.

---

## 1. Publication text — 7 substitutions

| # | Publication | Reason |
|---|---|---|
| 1 | NEO-AI-R-009 | DEF-IDENTIFIER-NOTE — internal identifier register named on a public page |
| 2 | NEO-AI-R-009 | DEF-FRONTMATTER-HOST — canonical rebound, internal gate reference removed |
| 3 | NEO-AI-R-009 | DEF-REGISTER-NOTE — internal path replaced by the public register URL; the provisional warning is kept |
| 4 | NEO-AI-R-009 | DEF-GOVERNANCE-CITE — internal instrument name replaced with reader-facing wording |
| 5 | NEO-AI-R-009 | DEF-GOVERNANCE-CITE — internal action reference generalised |
| 6 | NEO-AI-R-009 | DEF-GOVERNANCE-CITE — internal action reference removed from the citation block |
| 7 | NEO-AI-R-009 | DEF-GOVERNANCE-CITE — unpublished internal standard identifier replaced with reader-facing wording |

### What each one does

**1.** Pattern: ``NEO-AI-R-009` is requested at `PUB-ACT-02` and is not present in `data/identifiers\.json` v1\.5\. Cite this paper by title and version until the allo`  
DEF-IDENTIFIER-NOTE — internal identifier register named on a public page

**2.** Pattern: ``https://neoai\.myneogroup\.com/research/papers/model-intelligence-to-system-intelligence/` \(placeholder, gated by `PUB-OPEN-01`\)`  
DEF-FRONTMATTER-HOST — canonical rebound, internal gate reference removed

**3.** Pattern: `Capability statuses resolve from `data/capabilities\.json` v1\.2, which is PROVISIONAL pending Founder confirmation at gate P0-3\.`  
DEF-REGISTER-NOTE — internal path replaced by the public register URL; the provisional warning is kept

**4.** Pattern: ``LOCK_v2` makes that binding: a benchmark`  
DEF-GOVERNANCE-CITE — internal instrument name replaced with reader-facing wording

**5.** Pattern: ` \(pending the vocabulary amendment at `PUB-ACT-04`\)`  
DEF-GOVERNANCE-CITE — internal action reference generalised

**6.** Pattern: `Cite by title and version until an identifier is allocated at `PUB-ACT-02`\.`  
DEF-GOVERNANCE-CITE — internal action reference removed from the citation block

**7.** Pattern: ``NEO-AI-STD-003` requires an external primary source`  
DEF-GOVERNANCE-CITE — unpublished internal standard identifier replaced with reader-facing wording

---

## 2. Capability register — public projection, 6 substitutions

`registers/capabilities.json` is the internal canonical and is **not modified**.
The copy served at `/capabilities.json` and rendered on the register pages is a
projection of it. Statuses, keys and names are unchanged; internal gate, audit
and instrument references are removed. The served file declares this in a
`_public_projection` field.

| # | Matched | Reason |
|---|---|---|
| 1 | `PROVISIONAL - requires Founder confirmation (gate P0-3)…` | internal gate identifier removed; the provisional warning is preserved |
| 2 | `Named in five source texts, explained in none. Audit finding M8.…` | internal audit finding reference removed |
| 3 | `Designed and specified. Not launched. Audit finding X1.…` | internal audit finding reference removed |
| 4 | `Reproducible mission-level evaluation harness specified by NEO-AI-ENG-…` | unpublished internal identifier replaced; the non-publication is stated |
| 5 | ` This closes audit blocker B3: the previous gate definition required e…` | internal audit blocker reference removed |
| 6 | `which made them unmentionable under LOCK v2 s2.…` | internal instrument name replaced with reader-facing wording |

**The projection fails the build if a rule matches nothing.** A rule that stops
matching means the register changed and the rule was not updated, which would
otherwise let an internal reference through silently.

---

## 3. Site copy

YAML front matter is stripped from every file under `content/site/neoai/`. It
carries an internal source path (`source: … SITE_COPY_neoai.myneogroup.com.md`)
which must not reach a public page, and a document `h1` that would collide with
the one the page template supplies.

---

## 4. Verification

`build/verify_delta.py` check **CLS-13** scans every file in `upload/` — HTML,
JSON, XML, text — for internal identifiers and paths, and hard-fails on a match.
Check **CLS-14** reports trade-secret vocabulary that appears outside a
non-disclosure statement, for human sign-off rather than automatic failure,
because the corpus legitimately names what it withholds and a checker that
cannot tell disclosure from compliance must escalate rather than guess.

Current state: **CLS-13 clean, CLS-14 clean.**

