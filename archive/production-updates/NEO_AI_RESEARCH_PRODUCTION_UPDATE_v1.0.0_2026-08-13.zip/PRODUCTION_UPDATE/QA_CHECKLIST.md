# QA checklist

118 checks. **§A is the fourteen that stop a deployment.** Everything after that
is confirmation.

Automated coverage: `python3 build/verify_delta.py` runs 1,605 assertions over
the built tree and is green in this package. It cannot check anything that
depends on the live server — headers, redirects, real rendering — which is what
§A exists for.

---

## §A · Stop-the-deployment checks — 14

| # | Check | Expected | Failed → |
|---|---|---|---|
| A1 | `curl -sI /` | `200` | restore `.htaccess` backup |
| A2 | Homepage hero, WebGL and scroll behave as before | unchanged | restore `index.html` backup |
| A3 | Language selector lists 18 and switches | works | restore `index.html` |
| A4 | Arabic still renders RTL | `dir="rtl"` | restore `index.html` |
| A5 | Early-Access form submits and returns its JSON contract | unchanged | restore `index.html` |
| A6 | `curl -sI /research/` | `200` | check upload paths |
| A7 | R-009 page is styled | not a bare-HTML page | precondition P2 failed |
| A8 | `curl -sI /id/NEO-AI-R-009` | `302` to the canonical | `mod_rewrite` missing |
| A9 | `curl -sI /id/NEO-AI-R-001` | `404` | rewrite order wrong |
| A10 | Capability chips show the register status | `brain.router` = **S4** | **stop. do not continue** |
| A11 | No page says a capability is deployed that is not | none | **stop** |
| A12 | `curl -s /robots.txt \| grep Sitemap` | the subdomain | re-upload |
| A13 | `curl -sI /pdf/NEO-AI-R-009/v1.0.pdf` | `200`, `X-Robots-Tag: index, noarchive` | check block 5 |
| A14 | Browser console on `/` and on the R-009 page | no error | investigate before Phase B |

**A10 and A11 have no tolerance band.** A capability rendered as operational
that is not is the one failure this corpus cannot absorb: it retroactively
converts every other page into marketing. Withdraw the page, correct, re-run.

---

## §B · Landing page after M-08 — 11

The font restoration changes typography site-wide. This section exists only
because of that.

- [ ] B1 Space Grotesk, Inter and JetBrains Mono actually load (Network tab, `fonts.gstatic.com`, 200)
- [ ] B2 1920px — hero headline breaks where it should, no clipping
- [ ] B3 1440px — as above
- [ ] B4 1280px — nav pill fully visible, both ends
- [ ] B5 1100px — nav pill fully visible; the link row may scroll inside the pill
- [ ] B6 1080px — nav links collapse as before
- [ ] B7 768px — unchanged from before the release
- [ ] B8 390px — unchanged
- [ ] B9 Arabic at 1440 and 390 — RTL intact, no overflow
- [ ] B10 Chinese and Japanese — CJK falls back cleanly, no tofu
- [ ] B11 Counters, orchestration cards and the benchmark modal unaffected by the metric change

---

## §C · Research pages, desktop — 16

- [ ] C1 `/research/` lists exactly one publication and says so plainly
- [ ] C2 Institutional and Technical notes indexes each say "Nothing published in this category yet"
- [ ] C3 Held and Registered tables render on `/research/` and `/research/roadmap/`
- [ ] C4 R-009: contents list links land on the right section, offset clears the fixed nav
- [ ] C5 R-009: contents highlights the section you are reading
- [ ] C6 Claim chips `[E] [A] [D] [O]` render with tooltips
- [ ] C7 `[D]` chips carry the capability name and status and link to its page
- [ ] C8 Claim counts (4 / 4 / 3 / 3) match the evidence table at the foot of the paper
- [ ] C9 Tables scroll horizontally inside their border, not the page
- [ ] C10 First occurrence of a glossary term links to `/research/glossary/#term-…`; later ones do not
- [ ] C11 Unpublished references (`NEO-AI-R-001`) render as text carrying "registered, not drafted", never as a link
- [ ] C12 All 24 capability pages resolve, each showing status and ratification state
- [ ] C13 Glossary lists 39 terms and states that definitions are not yet published
- [ ] C14 Two topic hubs exist; the other three 404 (correct)
- [ ] C15 Breadcrumb on every page, matching its `BreadcrumbList`
- [ ] C16 Footer legal links open the modal via `/?legal=…` and the URL cleans itself

## §D · Research pages, tablet and mobile — 12

- [ ] D1 390px — no horizontal scroll on any of 15 routes (automated: `build/diag.js`)
- [ ] D2 360px — as above
- [ ] D3 768px — as above
- [ ] D4 Disclosure menu opens, closes on Escape, closes on outside click
- [ ] D5 Menu button reports `aria-expanded` correctly
- [ ] D6 Focus returns to the button on Escape
- [ ] D7 Tables are reachable by keyboard (the wrapper is `tabindex="0"`)
- [ ] D8 Contents list collapses to one column below 760px
- [ ] D9 Claim chips do not break mid-token
- [ ] D10 Long URLs in the citation block wrap
- [ ] D11 Tap targets ≥ 44px in the menu
- [ ] D12 iOS Safari — `backdrop-filter` degrades acceptably if unsupported

## §E · SEO — 15

- [ ] E1 Every route self-canonical (automated SEO-01/02)
- [ ] E2 `/search/` is `noindex, follow` and in no sitemap
- [ ] E3 `sitemap.xml` is an index over six children, all 200
- [ ] E4 Every indexable route appears in exactly one sitemap (automated MAP-02)
- [ ] E5 No sitemap contains a URL that 404s (automated MAP-01)
- [ ] E6 No version-pinned URL in any sitemap (automated MAP-03)
- [ ] E7 `lastmod` = 2026-08-12 everywhere, from the register not a file mtime
- [ ] E8 `robots.txt` denies Bytespider, allows CCBot, disallows the 7 filter params
- [ ] E9 `llms.txt` returns 200 and its blockquote carries all four claim classes
- [ ] E10 `llms.txt` contains no key-findings section and no summary beyond an abstract
- [ ] E11 Five Atom feeds validate; entry `id` is the identifier route, not the canonical
- [ ] E12 No feed carries a body
- [ ] E13 OpenGraph renders correctly in a real share (Slack or LinkedIn preview)
- [ ] E14 No `hreflang` anywhere — see `PREEXISTING_DEFECTS.md` D-4
- [ ] E15 Search Console: sitemap accepted, zero fetch errors after 48h

## §F · Structured data — 14

Validate at `validator.schema.org` and Google's Rich Results Test.

- [ ] F1 Every JSON-LD block parses (automated SD1)
- [ ] F2 Every referenced `@id` resolves to a node defined once (automated SD3)
- [ ] F3 No `Review`, `AggregateRating`, `Rating` (automated SD7)
- [ ] F4 No `interactionStatistic`, no view or download count (automated SD7)
- [ ] F5 No `offers` on the `SoftwareApplication` — the product is not generally available
- [ ] F6 `BreadcrumbList` only where a trail is rendered (automated SD-BC)
- [ ] F7 `variableMeasured` counts equal the counts rendered on the page (automated SD6)
- [ ] F8 `citation_technical_report_number` **absent** — R-009 has no allocated identifier (automated SD8)
- [ ] F9 The article node carries no `identifier` for the same reason (automated SD8b)
- [ ] F10 Every capability status in markup matches the register (automated SD10)
- [ ] F11 No `DefinedTerm` nodes — no definitional sentence is rendered, so none may be asserted
- [ ] F12 `Dataset` on the capability register carries version and `creativeWorkStatus: PROVISIONAL`
- [ ] F13 `dateModified` is not advanced by a rebuild
- [ ] F14 Every property has a rendered counterpart — spot-check five at random

## §G · Accessibility — 13

Target: WCAG 2.2 AA.

- [ ] G1 Skip link on every page, visible on focus (automated A11Y-01)
- [ ] G2 Exactly one `h1` per page (automated STR-01)
- [ ] G3 No heading level skipped (automated STR-02)
- [ ] G4 Every `img` has `alt` (automated A11Y-02)
- [ ] G5 Every table has a `caption` (automated A11Y-04)
- [ ] G6 Every scrollable table region is focusable and labelled (automated A11Y-03)
- [ ] G7 Visible focus ring on every interactive element
- [ ] G8 Keyboard-only pass through the R-009 page start to finish
- [ ] G9 Contrast, measured against `--bg` `#020208`. Every value below is computed, not estimated:

      19.19:1  --ink       #f4f6ff   headings, emphasis
      14.15:1  --hud       #69e6ff   kickers, accents
      13.12:1  #59e6a8               [E] chip
      10.24:1  --ink-2     #aeb6cf   body text
       6.99:1  --pink      #ff5a8c   [O] chip, warnings
       6.86:1  #ffffff on  --blue    button label
       5.51:1  --blue-soft #4d7bff   prose links
       4.89:1  --violet    #8b5cf6   [D] chip
       4.58:1  --ink-3     #6d7691   captions, breadcrumb, metadata

- [ ] G10 `--ink-3` at **4.58:1** clears AA-normal with almost no margin. It is
      inherited from `site.min.css` and is used only for secondary text.
      **Do not darken it**, and do not use it below 14px
- [ ] G11 Claim chips are not colour-only: each carries its letter and a `title`
- [ ] G12 `prefers-reduced-motion` removes transitions and transforms
- [ ] G13 Screen-reader pass on `/research/` and on the R-009 header

## §H · Performance — 9

- [ ] H1 R-009 page HTML ≤ 80 KB uncompressed (measured: 70.8 KB, 17.6 KB gzipped)
- [ ] H2 Research pages load no JS beyond `research.min.js` (6.1 KB) — **not** three.js, not the i18n bundle
- [ ] H3 `search-index.json` loads only when the field is typed into
- [ ] H4 gzip active on HTML, CSS, JS, JSON, XML
- [ ] H5 `sitemap.xml`, `robots.txt`, `llms.txt`, `capabilities.json` are `must-revalidate`
- [ ] H6 CSS and JS cached 7 days; PDF 30 days
- [ ] H7 Lighthouse on the R-009 page ≥ 95 performance, 100 SEO, ≥ 95 accessibility
- [ ] H8 No layout shift from the webfont swap (`display=swap` is set)
- [ ] H9 Time to first byte unchanged on the homepage

## §I · Links and routing — 12

- [ ] I1 No internal link 404s (automated LNK-01, whole tree)
- [ ] I2 No banned anchor text: "click here", "read more", "here" (automated STY-04)
- [ ] I3 Anchor text for a publication is its exact title
- [ ] I4 `/research/papers` → `301` → `/research/papers/`, one hop, no chain
- [ ] I5 No redirect loop anywhere
- [ ] I6 `/pdf/NEO-AI-R-009/latest.pdf` → `302` → `v1.0.pdf`
- [ ] I7 `/id/` → `302` → `/research/`
- [ ] I8 A nonsense URL under `/research/` returns the styled 404
- [ ] I9 The 404 page is `noindex`
- [ ] I10 Cross-host links to `mickaelmosse.ai` carry `rel="noopener"`
- [ ] I11 The Data Room link in the landing page still points where it did
- [ ] I12 External links open safely and are marked

## §J · Content integrity — 12

- [ ] J1 No internal identifier on any public page: `PUB-ACT-`, `PUB-OPEN-`, `LOCK_v2`, `P0-3`, `NEO-AI-STD-`, `identifiers.json` (automated CLS-13, every file)
- [ ] J2 Trade-secret vocabulary appears only inside a non-disclosure statement (automated CLS-14)
- [ ] J3 No internal filesystem path anywhere
- [ ] J4 The six text reductions in `REDUCTIONS.md` match what is on the page
- [ ] J5 The six register projections match `capabilities.json` as served
- [ ] J6 No claim strengthened relative to the frozen source — read the diff
- [ ] J7 R-009 renders complete: abstract through References and Version History
- [ ] J8 No benchmark number, no comparison to a named model, anywhere
- [ ] J9 The DRAFT status is visible on the publication page
- [ ] J10 The provisional register warning is visible on the register and on every capability page
- [ ] J11 No page presents a publication count as an achievement
- [ ] J12 The PDF text matches the HTML text

---

## Sign-off

| | Name | Date | Result |
|---|---|---|---|
| §A executed by | | | pass / **stop** |
| §B–§J executed by | | | pass / fail |
| Rollback rehearsed (Phase B revert), timed | | | ____ min (must be under 30) |
| Deployment authorised by | | | |

A rollback that has never been executed is a document, not a capability.
Rehearse it before you need it.
