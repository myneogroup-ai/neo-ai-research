# Route map

41 HTML routes are added and one (`/`) is modified. Every route is
self-canonical, and every indexable one appears in exactly one sitemap.

## 1. Routes added

| Route | Title | Robots | Canonical | Structured data |
|---|---|---|---|---|
| `/` **(modified, not added)** | NEO AI - The Enterprise Creation Operating System | `index, follow, max-snippet:-1, max-image-preview:large` | self | Organization, WebSite |
| `/404.html` | Not found | `noindex, follow` | none | — |
| `/research/` | Research | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, CollectionPage |
| `/research/about/` | About | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, Organization |
| `/research/authors/` | Authors | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/authors/mickael-mosse/` | Mickael Mosse | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/` | Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, Dataset |
| `/research/capability-register/assurance.eval-harness/` | Mission Evaluation Harness (assurance.eval-harness) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.cost-engine/` | Cost Engine (brain.cost-engine) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.event-bus/` | Event Bus (brain.event-bus) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.evidence-layer/` | Evidence Layer (brain.evidence-layer) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.evidence-ledger/` | Evidence Ledger (brain.evidence-ledger) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.governance/` | Governance (brain.governance) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.knowledge-graph/` | Knowledge Graph (brain.knowledge-graph) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.memory/` | Memory (brain.memory) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.router/` | Router (brain.router) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.task-graph/` | Task Graph (brain.task-graph) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain.validation/` | Validation (brain.validation) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/brain/` | The Brain (brain) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/dataroom.backend/` | Investor Data Room backend R6 (dataroom.backend) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/dataroom.frontend/` | Investor Data Room frontend (dataroom.frontend) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/deployment.cloud/` | Platform cloud deployment (deployment.cloud) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/deployment.onprem/` | On-premise and sovereign deployment (deployment.onprem) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/deployment.vpc/` | Client VPC deployment (deployment.vpc) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/foundation-model/` | NEO AI Foundation Model (foundation-model) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/lili/` | LILI (lili) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/mission-control/` | Mission Control (mission-control) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/mission.envelope/` | Mission Envelope (mission.envelope) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/neo-intelligence/` | NEO Intelligence (neo-intelligence) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/pilots/` | Signed paid pilots (pilots) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/capability-register/public-website/` | Public website (public-website) — Capability Register | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/glossary/` | Glossary | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, DefinedTermSet |
| `/research/institutional/` | Institutional publications | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, CollectionPage |
| `/research/methodology/` | Methodology | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, WebPage |
| `/research/papers/` | Research papers | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, CollectionPage |
| `/research/papers/model-intelligence-to-system-intelligence/` | From Model Intelligence to System Intelligence: How Orchestration Compounds Capability | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, ScholarlyArticle |
| `/research/roadmap/` | Roadmap | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/research/technical-notes/` | Technical notes | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, CollectionPage |
| `/research/topics/multi-model/` | Multi-model architecture | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, CollectionPage |
| `/research/topics/system-intelligence/` | System intelligence | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList, CollectionPage |
| `/research/updates/` | Updates | `index, follow, max-snippet:-1, max-image-preview:large` | self | BreadcrumbList |
| `/search/` | Search | `noindex, follow` | self | BreadcrumbList |

## 2. Non-HTML routes added

| Route | Serves |
|---|---|
| `/sitemap.xml` | sitemap index over six children |
| `/sitemaps/{publications,indexes,capability,glossary,figures,platform}.xml` | child sitemaps |
| `/feeds/all.xml` | every publication, abstract only |
| `/feeds/updates.xml` | corrections and errata, separate on purpose |
| `/feeds/{papers,institutional,technical-notes}.xml` | one per category |
| `/llms.txt` | AI-discovery index |
| `/capabilities.json` | machine-readable capability register |
| `/schema/entities.jsonld` | the entity graph |
| `/schema/capabilities-v1.json` | JSON Schema for the register |
| `/assets/search-index.json` | build-time search index |
| `/pdf/NEO-AI-R-009/v1.0.pdf` | the publication binary |

## 3. Rewrite routes, served by `.htaccess`

| Route | Behaviour | Why |
|---|---|---|
| `/id/NEO-AI-R-009` | **302** to the canonical | An identifier route always redirects, so a canonical move never breaks a citation |
| `/id/NEO-AI-R-009/v1.0` | **302** to the canonical | v1.0 is the current version; no pinned archive exists until a MAJOR revision creates one |
| `/pdf/NEO-AI-R-009/latest.pdf` | **302** to `v1.0.pdf` | |
| `/id/NEO-AI-<any other>` | **404** | Registered but unpublished. Redirecting it to the roadmap would make an unresolvable identifier appear to resolve |
| `/id/` | 302 to `/research/` | |
| `/research/<path>` without a trailing slash | **301**, one hop | |

**Never a 301 on an identifier route.** A 301 is cached by the citing client and
freezes the resolution, which defeats the reason the route exists.

## 4. Sitemap membership

| Sitemap | URLs |
|---|---|
| `publications.xml` | 1 |
| `indexes.xml` | 13 |
| `capability.xml` | 25 |
| `glossary.xml` | 1 |
| `figures.xml` | 0 — empty, and the file exists so the index does not point at a 404 |
| `platform.xml` | 1 |

`/search/` is `noindex, follow` and is in no sitemap. No version-pinned URL
reaches any sitemap; the build asserts that on its own output rather than
trusting its input.

## 5. Topic hubs: two built, three withheld

`docs/06_CANONICAL_URL_MAP.md` defines five hubs. A hub lists only publications
that resolve, and the same rule that refused `/research/private-ai/` applies to
the rest of them.

| Hub | Members | Built |
|---|---|---|
| `system-intelligence` | R-009, P-001, R-001 | **yes** — R-009 resolves |
| `multi-model` | R-001, R-009 | **yes** — R-009 resolves |
| `mission-control` | R-003, TN-001, TN-003 | no — none resolves |
| `evidence-memory` | R-005, TN-002 | no — none resolves |
| `governance` | R-003, P-007, TN-001 | no — none resolves |

The frozen `scripts/gen_seo.py` hardcoded all five into `indexes.xml`
regardless. Deploying that would have published three empty indexed pages.
The build now derives hub membership and reports what it skipped.

The three withheld hubs appear automatically once a member is published. No code
change is needed.

## 6. Platform routes: declared by the frozen build, not built here

The frozen generator declared twelve platform and company routes.
**Eleven of them do not exist on the live site**, which is a single
anchor-scrolled page: `#golive`, `#power`, `#bench`, `#usecases`, `#mission`,
`#verticals`, `#intel`, `#investors`, `#waitlist`.

`sitemaps/platform.xml` therefore carries the homepage alone. Shipping the
frozen version would have submitted eleven URLs that 404.

Content for all eleven is finalized in
`build/corpus/content/site/neoai/platform/`. Building them is a separate
release: `/platform/`, `/platform/system-intelligence/`,
`/platform/mission-control/`, `/platform/observe-build/`, `/platform/lili/`,
`/platform/evidence/`, `/platform/governance/`, `/platform/security/`,
`/platform/deployment/`, `/company/`, `/company/contact/`.

## 7. Rules that survive any host move

Slugs are frozen at first publication. No date and no version number in a path.
No category word duplicated in a path. One full text per publication, never a
second rendering. Three URL classes with three guarantees: a canonical never
redirects, an identifier route always 302s, a pinned version is immutable and is
never redirected forward. Filter parameters are `noindex, follow` and are
disallowed in robots. `lastmod` advances only on a content change, which is why
it comes from the register and not from a file timestamp.
