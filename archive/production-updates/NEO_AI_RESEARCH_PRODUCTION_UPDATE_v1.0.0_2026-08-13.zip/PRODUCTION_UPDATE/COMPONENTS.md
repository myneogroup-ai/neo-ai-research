# Components

**There is no React and no Next.js in this package, deliberately.**

The brief asked for a React / Next component inventory. The deployed site is
static HTML with vanilla JavaScript on Apache — `index.html`, seven hand-rolled
`.min.js` files, `three.min.js` for the WebGL sequence, a PHP relay for the
form. There is no bundler, no `package.json`, no build step and no Node runtime
on the server.

Introducing a React tree for the research section would mean two rendering
models on one site, a build toolchain the current deployment process does not
have, and — most damaging for this corpus specifically — a client-rendered
document at a moment when `docs/10_SEO_AND_DISCOVERY.md` requires that *every
publication body, abstract, glossary definition, capability status, citation
block and reference list is present in the initial HTML response*, readable by a
retrieval system that executes no JavaScript.

So the components below are **build-time template functions in
`build/neo_research_build.py`**, not runtime components. Each emits HTML into
the static output. Where a runtime behaviour is genuinely needed, it is
progressive enhancement over already-rendered markup.

If the site is ever migrated to Next.js, this table maps one-to-one onto a
component tree, which is why it is expressed this way.

---

## 1. Build-time templates

| Component | Function | Emits | Used by |
|---|---|---|---|
| `PageShell` | `page()` | full document: head, nav, breadcrumb, main, footer, JSON-LD | all 41 routes |
| `PrimaryNav` | `nav_html()` | `.r-nav` with 9 links, logo, disclosure button, CTA | all |
| `Breadcrumb` | `crumb()` | `.r-crumb` ordered list | all except `/404.html` |
| `Footer` | `FOOTER` constant | link row, corporate line, licence, `rel=me/author/publisher` | all |
| `PublicationPage` | `publication_page()` | document header, claim bar, contents, capability summary, body, citation block | 1 route |
| `LibraryIndex` | `build_indexes()` | claim-class legend, three category sections, held table, registered table | `/research/` |
| `CategoryIndex` | `build_indexes()` | card grid or a stated-empty state, plus the category feed link | 3 routes |
| `TopicHub` | `build_indexes()` | card grid, built only when a member resolves | 2 routes |
| `CapabilityRegister` | `build_capability_pages()` | status definitions, full register table, distribution | 1 route |
| `CapabilityPage` | `build_capability_pages()` | status pill, ratification state, parent link, referenced-by | 24 routes |
| `GlossarySet` | `build_glossary()` | term list with per-term anchors, prohibited synonyms | 1 route |
| `Roadmap` | `build_static_pages()` | three tables: uncleared, held, registered | 1 route |
| `AboutOrg` | `build_static_pages()` | `Organization` entity page | 1 route |
| `AuthorPage` | `build_static_pages()` | author, publications, absent-ORCID note | 2 routes |
| `Updates` | `build_static_pages()` | corpus changelog, empty errata section | 1 route |
| `SearchPage` | `build_static_pages()` | search form, results container, `noscript` fallback | 1 route |
| `NotFound` | `build_404()` | 404, including the unpublished-identifier explanation | 1 route |
| `PdfDocument` | `build_pdf_source()` | print-only HTML, rendered to PDF by `make_pdf.js` | 1 binary |

## 2. Content-level partials

Emitted inside the body, from the same module.

| Partial | Function | What it renders |
|---|---|---|
| `ClaimChip` | `render_claims()` | `[E] [A] [D] [O]`. A `[D]` chip resolves its capability from the register and **fails the build** if the key is absent or the status disagrees |
| `PublicationRef` | `render_pubrefs()` | a link if the target resolves; otherwise plain text carrying "registered, not drafted" — never a dead link |
| `GlossaryLink` | `link_first_glossary()` | first occurrence only, with headings, code, tables, links and existing chips masked out |
| `TableRegion` | `wrap_tables()` | focusable scroll region with a caption taken from the nearest preceding heading |
| `Toc` | `build_toc()` | stable ids on every h2/h3, plus the hover anchor |
| `PubCard` | `pubcard()` | identifier line and title, used by every index and hub |
| `ClaimBar` | inline | the four counted totals, computed from the evidence table |
| `CapabilityTable` | inline | key, name, status, resolved at build time |

## 3. Runtime behaviour — one file, 6.1 KB

`assets/js/research.min.js`, `defer`, no dependencies. Everything it does is an
enhancement of markup that is already rendered.

| Behaviour | Degrades to |
|---|---|
| Disclosure navigation below 1080px | the links are in the DOM; only the toggle is lost |
| Contents highlighting | a plain list of working links |
| Search | the `noscript` block listing the four entry points |

**It deliberately does not load any v17.2 script.** `app-runtime.min.js`
dereferences `#langSel` without a guard and throws when that element is absent,
which would kill every later script on the page. `verify_delta.py` check
**JS-02** asserts no research page ever loads it.

Two further runtime files ship for the **landing page** only:
`research-nav-i18n.min.js` (one dictionary key, 18 languages) and
`legal-deeplink.min.js` (opens the existing legal modal from `?legal=`).

## 4. Styles

| File | Scope | Size |
|---|---|---|
| `assets/css/research.min.css` | `body.research` only | 18.5 KB |
| `assets/css/nav-fit.min.css` | `.nav`, both surfaces | 1.8 KB |

`site.min.css` is not modified. `research.min.css` consumes its `:root` tokens
and redefines none of them; it adds four research-only variables under
`body.research`. The three global rules it overrides, and the one absent rule it
supplies, are documented in the file's own header.

## 5. If this is ported to Next.js later

The mapping is direct: each build-time template becomes a server component, the
registers become the data layer, `render_claims` / `render_pubrefs` /
`link_first_glossary` become MDX plugins, and `research.min.js` becomes two
small client components. The constraint that must survive the port is the one in
§1: **the body must be in the initial HTML response.** `app/` router with server
components satisfies it; a client-side data fetch does not.
