# Search

## What ships

A client-side search over a build-time index. One route, one JSON file, no
server, no third-party service, no request leaves the reader's browser.

| | |
|---|---|
| Route | `/search/` — `noindex, follow`, in no sitemap |
| Index | `/assets/search-index.json` — 72 documents, 10.0 KB uncompressed, ~3 KB gzipped |
| Code | inside `assets/js/research.min.js`, no dependency |
| Loading | the index is fetched on the **first keystroke**, never on page load |

## Why not a hosted search service

Three reasons, in order of weight.

**The corpus is 72 documents.** An index that fits in one small JSON file does
not need a search backend, and adding one would introduce an availability
dependency for a feature that currently cannot fail.

**Privacy.** A hosted search sends every query to a third party. A reader
evaluating a governance corpus is exactly the reader who will notice.

**The deployment target.** Apache on shared hosting, no Node runtime, no build
step in the release process. A service integration would be the only part of the
site that could not be rolled back by deleting files.

At roughly 500 documents this stops being the right answer. The index format is
deliberately trivial so that swapping it costs one file.

## Index composition

| Kind | Count | Source |
|---|---|---|
| Publications | 1 | `registers/publications.json`, live entries only |
| Capability keys | 24 | `registers/capabilities.json` |
| Glossary terms | 39 | `registers/vocabulary.json` |
| Pages | 6 | the static routes |
| Topic hubs | 2 | only those that resolve |

Derived, never typed. When a publication clears, rebuilding regenerates the
index; there is no second place to update.

Record shape, four keys to keep it small:

```json
{"t":"title","u":"/route/","k":"kind label","s":"snippet"}
```

## Ranking

Deliberately simple, and simple is defensible on a corpus this size.

| Match | Score |
|---|---|
| exact title | 100 |
| title starts with the term | 40 |
| title contains the term | 22 |
| kind label contains it | 8 |
| snippet contains it | 4 |

Terms are summed, results sorted, top 30 shown, matches highlighted with
`<mark>`. Minimum query length is two characters and input is debounced at
130ms.

## What it covers, and what it does not

**Covers** every publication title and abstract, all 24 capability keys and
names, all 39 glossary terms, the index pages, the topic hubs.

**Does not cover full publication body text.** Indexing the body of R-009 would
add roughly 45 KB to a 10 KB index for one document, and would grow linearly
with the corpus. The contents list, the claim chips and the browser's own
in-page find already serve the reader who is inside a paper. When the corpus
passes about twenty publications this trade should be revisited: a per-paper
section index is the next step, not full text.

**States the corpus size when it finds nothing.** An empty result explains that
six identifiers are approved and one document is published, and links to the
roadmap. A search that returns nothing on a small corpus should say why rather
than imply the reader mistyped.

## Without JavaScript

`/search/` renders a `noscript` block listing the four entry points — the
library index, the Capability Register, the Glossary and the Roadmap. Nothing
findable through search is reachable *only* through search.

This is why the route is `noindex`: it is a tool, not content, and every
document it can reach is indexed at its own canonical URL.

## Deep links

`/search/?q=router` prefills and runs. The parameter is disallowed in
`robots.txt` and the route is `noindex, follow`, so it creates no indexable
surface.

## Accessibility

Labelled input, `aria-describedby` on the help text, `aria-live="polite"` on the
results container so a screen reader is told when results change, results are
plain links in DOM order, and focus is placed in the field on load with
`preventScroll`.
