# SEO and discovery

## 1. Rendering first, because everything else depends on it

Every publication body, abstract, glossary term, capability status, citation
block and reference list is in the **initial HTML response**. No critical content
arrives by client-side fetch. A retrieval system that executes no JavaScript
reads the entire corpus.

`verify_delta.py` check **JS-01** strips every `<script>` from every page and
fails if fewer than 120 words remain. Current minimum across 41 routes: well
above it, and the R-009 page renders 100% of its text with JavaScript disabled.

Progressive enhancement is confined to three things, each degrading to rendered
markup: the disclosure menu, contents highlighting, and search.

Semantic markup: one `h1` per page, `<article>` around bodies, `<time datetime>`
on dates, `<cite>` on references, `<dl>` for the glossary, `<table>` with
`<caption>` and `<th scope>`, headings descending without a skipped level.
Checks STR-01 through STR-05.

## 2. Generated, never written

| File | Generated from |
|---|---|
| `sitemap.xml`, `sitemaps/*.xml` | `registers/publications.json` + `capabilities.json` |
| `feeds/*.xml` | the same registers |
| `llms.txt` | the same registers |
| `capabilities.json` | `registers/capabilities.json`, via the public projection |
| `assets/search-index.json` | all three registers |
| `robots.txt` | **authored**, not generated |

A hand-written discovery file drifts from the corpus silently, and the drift is
invisible until a retrieval system acts on it.

## 3. Sitemaps

`sitemap.xml` is an index over six children: publications (1), indexes (13),
capability (25), glossary (1), figures (0), platform (1).

- **Version-pinned URLs never reach a sitemap.** The build asserts this on its
  own output rather than trusting its input, because the assumption is the thing
  that fails.
- **`lastmod` reflects a content change only.** It comes from the register, not
  from a file timestamp. A rebuild does not advance it. A `lastmod` that moves
  without a content change is a false freshness signal and degrades trust in
  every subsequent one.
- **`figures.xml` is empty and present.** The index would otherwise point at a
  404.
- **`platform.xml` carries the homepage alone.** The frozen generator declared
  twelve platform routes; eleven do not exist. See `ROUTE_MAP.md` §6.

## 4. robots.txt

Bytespider denied. **CCBot allowed** — a deliberate change, not an oversight:
the earlier standard denied it because this host carried no publication text,
and the reason for the denial went with the reason for the host. The seven
filter parameters and `/search` are disallowed. `/capabilities.json`, `/pdf/`
and `*.svg` are explicitly allowed. Sitemap rebound to the subdomain.

The WordPress root at `myneogroup.com/robots.txt` is a separate file and needs
the sitemap line added there too. `PREEXISTING_DEFECTS.md` D-2.

## 5. Feeds

Atom 1.0. `feeds/all.xml` plus one per category plus `feeds/updates.xml`.

Each entry carries title, `id`, published, updated, an alternate link, a
category and a summary containing **the abstract only**. Feeds never carry the
body — check DIS-08 asserts it.

**The entry `id` is the permanent identifier route, not the canonical URL.** A
canonical move then does not create a duplicate entry in every reader. Check
DIS-07.

`updates.xml` is separate on purpose: a reader who has already cited a document
needs corrections to it far more than they need new documents. It is empty
today, and it exists before it is needed, because a corrections process invented
during an incident is not credible.

## 6. llms.txt

A proposed convention no major retrieval system has committed to honouring. It
costs one generated file and the downside is zero, so it exists.

The structural requirement is the substance: **the intro blockquote carries all
four claim classes**, so a system reading only the first two hundred words
learns that this corpus distinguishes evidence from interpretation from intent
from an open question. Check DIS-04.

**One deliberate omission.** No summary of any paper beyond its abstract, and no
key-findings section. A generated summary of a paper that reports no measurement
is exactly where a system inventing a finding would get it. Check DIS-05.

It also names the roadmap, so a system that notices the corpus is smaller than
the register can resolve why without guessing.

## 7. Canonical policy

Every route is self-canonical. Zero cross-host canonicals point away from
`neoai.myneogroup.com` for institutional research.

Three URL classes, three guarantees:

| Class | Guarantee |
|---|---|
| a canonical | never redirects |
| an identifier route `/id/<PUBID>` | always **302**s, never 301 |
| a version-pinned archive | immutable, `noindex`, in no sitemap, never redirected forward |

A 301 on an identifier route is cached by the citing client and freezes the
resolution, which defeats the reason the route exists. Forwarding a pinned
version to the current one looks like tidiness and silently falsifies the
citation record; it is the one failure no rollback repairs.

No pinned archive exists yet — none has taken a MAJOR version. The rule is
implemented now so it is not invented under pressure later.

## 8. Language

English at the root. **No `/en/` prefix, now or ever.** A future language mounts
at `/<iso-639-1>/`, mirroring the English tree exactly, so English URLs never
move and a multilingual wave breaks no citation. Every two-letter ISO 639-1 code
is reserved as a first path segment.

**No `hreflang` is emitted anywhere**, because the eighteen landing-page
languages have no per-language URL: every alternate would point at the same
document and reciprocity could not be satisfied. `PREEXISTING_DEFECTS.md` D-4.

## 9. Linking discipline

| Class | Target | Enforced |
|---|---|---|
| anchor text for a publication | the exact title | STY-04 |
| banned: "click here", "read more", "here", "this paper" | — | STY-04 |
| glossary terms | first occurrence only, from the register | build |
| capability keys | one link per referenced key | build |
| unresolvable references | rendered as text, never as a link | build |
| internal links | must resolve | LNK-01, whole tree |

Exclusion zones for first-occurrence linking: headings, code, tables, existing
links, claim chips.

## 10. What is not done, and will not be

No keyword stuffing, no cloaking, no doorway page, no synonym page, no text spun
for a query. The corpus competes on being worth citing.

**Nothing is promised.** Not a ranking position, not that AI systems will cite
the corpus, not that this release preserves traffic. Structured data produces
eligibility for presentation features and machine legibility, and nothing more.

## 11. Two risks specific to this corpus

**The corpus is smaller than the register.** One publication against nineteen
identifiers. Indexes render what exists, the roadmap names what is registered
with no dates, and no page presents a count as an achievement.

**The strongest page carries the least keyword surface.** The methodology page
is the corpus's best argument for its own trustworthiness and nobody searches
for it. That is acceptable. It exists to be found by a reader who has already
arrived, and to be the page a sceptical evaluator reaches from any other. It is
linked from every publication, from the library index and from `llms.txt`, and
it is not optimised for a query.
