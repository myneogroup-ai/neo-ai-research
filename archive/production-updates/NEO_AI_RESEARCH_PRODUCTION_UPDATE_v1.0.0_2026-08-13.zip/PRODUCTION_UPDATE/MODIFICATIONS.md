# Files to modify

Six existing files change. Four are replaced wholesale with a supplied file;
`index.html` is replaced with a supplied file that differs from yours by
insertions only; `.htaccess` is replaced with a superset of yours.

**No existing line of markup, style or script is modified in place anywhere in
this release.** `MODIFICATIONS_index.diff` proves it for `index.html`: +66 lines,
−0 lines.

The exact anchors are given for every change so you can apply them by hand or
verify that the supplied file patched the right place. `build/patch_index.py`
asserts each anchor occurs **exactly once** and aborts otherwise.

---

## Summary

| # | File | Action | Risk | Reversal |
|---|---|---|---|---|
| M-01 | `index.html` | insert into `<head>` | **Low** | restore backup |
| M-02 | `index.html` | insert one nav link | **Medium** — this is the publication moment | remove the line |
| M-03 | `index.html` | insert two `<script>` tags | Low | remove the lines |
| M-04 | `index.html` | insert one footer link | Low | remove the line |
| M-08 | `index.html` | restore the webfont `<link>` | **Medium** — changes typography site-wide | remove the line |
| M-05 | `robots.txt` | replace | **Medium** — crawler-visible | restore backup |
| M-06 | `sitemap.xml` | replace | **Medium** — crawler-visible | restore backup |
| M-07 | `.htaccess` | replace with a superset | **High** — a syntax error 500s the site | restore backup |

Source file this package was built against:
`sha256 836bbfbaec245e3ce13449f8595837ae77740cf60fcc24b410ba72db68dc1ee6`

---

## M-01 · `index.html` — canonical, robots, social cards, entity graph

**Why.** The deployed head carries a title and a description and nothing else.
There is no `rel=canonical`, no robots directive, no OpenGraph, no Twitter card
and no structured data. A link shared to Slack or LinkedIn today renders as a
bare URL, and the page asserts nothing machine-readable about who publishes it.

**Anchor** (occurs once):

```html
<link rel="stylesheet" href="assets/css/site.min.css">
</head>
```

**Becomes:** the same line, then the canonical, the robots directive, five
OpenGraph and three Twitter properties, one Atom `alternate`, and one JSON-LD
`@graph` carrying `WebSite`, `SoftwareApplication`+`Brand`, and three
`Organization` nodes, then `</head>`. See `MODIFICATIONS_index.diff`
for the literal block.

**Every property asserts something the page already renders.** The
`Organization` address, the licence number and the parent-company relationship
are all in the footer text. There is no `offers`, no `aggregateRating` and no
`interactionStatistic`: the product is not generally available and markup saying
otherwise would be a false claim in the plainest sense.

**Dependencies.** The `@id` values are referenced by every research page, which
points at them rather than restating them. Deploying research pages without M-01
leaves five dangling `@id` references. **M-01 and the research tree deploy
together.**

**Not included, deliberately:** `hreflang`. See `PREEXISTING_DEFECTS.md` D-4 —
the eighteen languages have no per-language URL, so every `hreflang` would point
at the same document and the reciprocity requirement could not be met.

---

## M-02 · `index.html` — Research enters the primary navigation

**Why.** This is Phase B of the deployment plan, "the publication moment".
Until this line exists the corpus is live and unlinked, which is Phase A and is
deliberately reversible in seconds.

**Anchor** (occurs once, four-space indent):

```html
    <a href="#investors" data-i18n="nav.investors">Investors</a>
```

**Becomes:**

```html
    <a href="/research/" data-i18n="nav.research">Research</a>
    <a href="#investors" data-i18n="nav.investors">Investors</a>
```

**Placement.** Before Investors, not after. Research precedes the commercial ask
in reading order, and the CTA stays last.

**Nav capacity — measured, and it required a second change.** The bar now
carries nine links plus the language selector plus the CTA. Measured on the
unmodified v17.2 build, the eight-link pill is already **1278px wide**, and
`.nav .links` does not collapse until 1080px. Between 1081px and 1278px the
deployed pill is therefore wider than the viewport and its ends are silently
clipped by `body{overflow-x:hidden}` — at a 1100px viewport it overhangs by
89px. **That defect predates this release** (`PREEXISTING_DEFECTS.md` D-6), and
the ninth link would have taken the pill to 1353px and widened the band.

`assets/css/nav-fit.min.css` is therefore added and loaded on both surfaces. It
tightens gap, link size and CTA padding between 1081 and 1400px, bounds the pill
at `calc(100vw - 20px)`, and lets the link row scroll inside the pill as a last
resort rather than be clipped by the body.

Measured after the change, at twenty widths from 360 to 1920px: **no viewport
overflow at any width, on either the landing page or a research page.** The
nine-link bar at 1280px is 1207px, narrower than the deployed eight-link bar's
1278px, so the release closes the pre-existing gap instead of widening it. Full
table in `QA_EVIDENCE/nav-widths.txt`.

**Translation.** `data-i18n="nav.research"` resolves through M-03a. Without
M-03a the existing `applyLang()` does `if(dict[k])`, the key is absent, and the
markup text "Research" survives untranslated in all eighteen languages. Degraded,
never broken.

**This is the single highest-risk line in the release** and the single easiest
to reverse. Deleting it returns the site to Phase A while every research URL
stays live and citable.

---

## M-03 · `index.html` — two new scripts

**M-03a. Anchor** (occurs once):

```html
<script defer src="assets/js/app-i18n.min.js"></script>
<script defer src="assets/js/app-runtime.min.js"></script>
```

**Becomes:**

```html
<script defer src="assets/js/app-i18n.min.js"></script>
<script defer src="assets/js/research-nav-i18n.min.js"></script>
<script defer src="assets/js/app-runtime.min.js"></script>
```

**ORDER IS LOAD-BEARING.** `app-i18n.min.js` declares `const I18N`;
`research-nav-i18n.min.js` adds one key to each of the eighteen dictionaries;
`app-runtime.min.js` reads them. All three are `defer`, so document order is
execution order. Moving the new file before `app-i18n` makes it a no-op — it
guards on `typeof I18N === 'undefined'` and returns silently.

**Why not edit `app-i18n.min.js` directly.** It is 362 KB, holds all eighteen
dictionaries, and is under the v17.2 regression lock. Mutating one property of
the existing object gets the same result with no edit to a locked artefact and
no merge conflict on the next translation pass.

**M-03b. Anchor** (occurs once, the last script line):

```html
<script defer src="assets/js/app-universe.min.js"></script>
```

**Becomes:** the same line, then

```html
<script defer src="assets/js/legal-deeplink.min.js"></script>
```

**Must be last**, so the delegated `[data-legal]` handler inside
`app-sections.min.js` is already bound when it fires. It opens the existing legal
modal for `/?legal=privacy|terms|cookies` and then strips the parameter with
`history.replaceState`, so no state-bearing URL is shared or crawled.

**Why this exists.** Research pages are separate documents and cannot host the
legal modal, whose text lives inside `app-sections.min.js`. Copying that text
into a second file would create two sources of truth for a legal notice.

---

## M-04 · `index.html` — Research in the footer

**Anchor** (occurs once, six-space indent):

```html
<div class="f-links" id="fLinks">
      <a href="#investors" data-i18n="nav.investors">Investors</a>
```

**Becomes:**

```html
<div class="f-links" id="fLinks">
      <a href="/research/" data-i18n="nav.research">Research</a>
      <a href="#investors" data-i18n="nav.investors">Investors</a>
```

Same `data-i18n` key as M-02, so one dictionary entry serves both.

---

## M-08 · `index.html` — restore the webfont stylesheet

**This is a bug fix, not a design change, and it has visual consequences.
Read this section before applying it.**

**The finding.** `index.html` requests three families in CSS — `Space Grotesk`,
`Inter`, `JetBrains Mono` — and never loads any of them. The head carries the
two `preconnect` hints to `fonts.googleapis.com` and `fonts.gstatic.com` and no
stylesheet link. There is no `@import` in `site.min.css` and no `@font-face`
anywhere in the package.

**The evidence it is accidental.**
`preview/NEO_AI_single_file_preview.html`, shipped in the same v17.2 delivery,
**does** carry the link:

```
https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap
```

The stylesheet link was lost when the single-file preview was split into the
deployed package. The orphaned preconnects are its fingerprint. The live site
has rendered in fallback faces since v17.2 shipped.

**Anchor** (occurs once):

```html
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
```

**Becomes:** the same line, then the `<link rel="stylesheet">` above, byte-identical
to the preview's.

**Consequence, stated plainly.** Applying M-08 changes the typography of the
entire landing page, in every language, at every breakpoint. It is what the
design intends and what the QA screenshots in the v17.2 delivery show, but it is
still a visible change to a regression-locked page, and text metrics shift:
Space Grotesk is wider than the system fallback at the same size, so headline
line-breaks will move.

**If you want to defer it,** delete the one line from the supplied `index.html`
and delete the matching `<link rel="stylesheet">` from
`upload/assets/css/research.min.css`'s consumers — that is, from the `FONTS`
block emitted into every research page (`build/neo_research_build.py`, constant
`FONTS`), then rebuild. Both surfaces must make the same choice: applying M-08
to one and not the other gives you two typographies on one site, which is worse
than either uniform outcome.

**Recommendation: apply it, and give the landing page its own visual QA pass at
1920 / 1440 / 768 / 390 in English and in Arabic** (RTL is where a metric change
is most likely to reflow badly). `QA_CHECKLIST.md` §B covers it.

---

## M-05 · `robots.txt` — replace

**Why.** The deployed file is wrong for the host it is on. It declares
`Sitemap: https://myneogroup.com/neoai/sitemap.xml` — the subpath from the v17.2
delivery — while the file is being served from the subdomain. A crawler
following it is sent to a different host.

**Deployed:**

```
User-agent: *
Allow: /
Sitemap: https://myneogroup.com/neoai/sitemap.xml
```

**Replaced by** `upload/robots.txt`: `Bytespider` denied, `CCBot` allowed
deliberately (this host now carries the corpus, and the reason for the earlier
denial went with the reason for the host), the seven filter parameters
disallowed, `/search` disallowed, `/capabilities.json`, `/pdf/` and `*.svg`
explicitly allowed, and the sitemap rebound to
`https://neoai.myneogroup.com/sitemap.xml`.

**Also required, and outside this package.** The WordPress root at
`https://myneogroup.com/robots.txt` is a separate file on a separate host.
See `PREEXISTING_DEFECTS.md` D-2 for what to do there.

---

## M-06 · `sitemap.xml` — replace

**Why.** The deployed sitemap contains exactly one URL,
`https://myneogroup.com/neoai/`, which is not the URL the page is served at.

**Replaced by** a sitemap **index** pointing at six child sitemaps. The old
single `<urlset>` becomes `sitemaps/platform.xml`, corrected to the subdomain.

**One deliberate reduction.** The frozen `gen_seo.py` declared twelve platform
routes (`/platform/lili/`, `/company/` and so on). Eleven of them do not exist.
`sitemaps/platform.xml` therefore carries the homepage alone. Building those
eleven pages is a separate release; declaring them here would ship eleven
indexed 404s. See `ROUTE_MAP.md` §6.

---

## M-07 · `.htaccess` — replace with a superset

**Highest-risk change in the release: an Apache syntax error returns 500 for the
whole site, including the landing page.** Upload it on its own, load the
homepage, and only then upload the rest.

**Every directive from your v17.2 file is carried forward verbatim in block 1:**
`Options -Indexes`, the four `mod_expires` rules, and the `relay.config.php`
deny. Nothing is dropped. Diff before uploading if you have edited it since
v17.2 shipped.

**Six blocks are added:**

| Block | Adds | If your host lacks the module |
|---|---|---|
| 2 | media types for `.jsonld` and Atom, caching for JSON/Atom/PDF, no-cache for `sitemap.xml`, `robots.txt`, `llms.txt` and `capabilities.json`, gzip | wrapped in `<IfModule>`; degrades silently |
| 3 | `X-Content-Type-Options`, `Referrer-Policy`, `X-Frame-Options` | wrapped in `<IfModule mod_headers.c>` |
| 4 | the `/id/<PUBID>` resolver, and a one-hop trailing-slash rule for `/research` and `/search` | **requires `mod_rewrite`. Verify it before deploying** |
| 5 | `X-Robots-Tag: index, noarchive` on PDFs | `<IfModule mod_headers.c>` |
| 6 | `ErrorDocument 404 /404.html` | core |
| 7 | a comment only | — |

**No Content-Security-Policy.** `index.html` carries an inline configuration
script and an inline `<style>`, and a CSP added without auditing those would
break the landing page. Tracked as a separate change in `AUDIT_CTO_FINAL.md` §5.

**Resolver semantics.** `/id/NEO-AI-R-009` → `302` to the canonical. Always
`302`, never `301`: a `301` is cached by the citing client and freezes the
resolution, which defeats the reason the identifier route exists. An identifier
that is registered but not published returns **404**, not a redirect to the
roadmap — making an unresolvable identifier appear to resolve is the failure the
register exists to prevent.

---

## Files explicitly NOT modified

`assets/css/site.min.css` · `assets/js/three.min.js` · `vendor.min.js` ·
`app-i18n.min.js` · `app-runtime.min.js` · `app-sections.min.js` ·
`app-engine.min.js` · `app-universe.min.js` · `assets/relay.php` ·
`assets/favicon.svg` · everything under `server-config/`.

The regression lock from v17.2 holds: opening halo, cinematic hero, orbital
cards, WebGL sequence, scroll choreography, Foundation Model chamber, Industry
Universe, NEO Intelligence, Business Model, investor section, Data Room URL,
LILI identity, the eighteen-language selector, the legal modal, the cookie
notice, responsive behaviour, reduced-motion support and the visual identity are
all untouched — with the single, documented exception of the font faces those
elements are drawn in (M-08).
