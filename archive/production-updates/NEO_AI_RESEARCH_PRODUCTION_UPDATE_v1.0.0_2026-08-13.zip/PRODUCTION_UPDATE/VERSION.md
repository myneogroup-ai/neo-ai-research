# Version

| | |
|---|---|
| Package | `research-delta-1.0.0` |
| Built | 13 August 2026 |
| Built against | `NEO_AI_WEBSITE_PRODUCTION_v17.2` |
| Source `index.html` | `sha256 836bbfbaec245e3ce13449f8595837ae77740cf60fcc24b410ba72db68dc1ee6` |
| Corpus | `NEO_AI_Research_Repository_FROZEN`, corpus date 2026-08-12 |
| Capability register | v1.2, **PROVISIONAL** |
| Controlled vocabulary | v1.0, 39 terms |
| Publications live | 1 of 19 registered identifiers |
| Files | 68 (4 replace, 64 add) |
| Routes added | 41 HTML + 15 non-HTML + 6 rewrite classes |
| Conformance | `verify_delta.py`, 1,605 checks, PASS |

## Two version scales, never conflated

| Scale | Applies to | Lives in |
|---|---|---|
| Document version `v<MAJOR>.<MINOR>` | one publication | its front matter and version history |
| Corpus version `corpus-v<M>.<m>.<p>` | the repository at a point in time | git tags and the corpus changelog |

A reader cites a **document** version. The corpus version exists so a build can
be reproduced. This package adds a third, `research-delta-<M>.<m>.<p>`, which
versions the **website integration** and is not cited by anyone.

## Document versions in this release

| Identifier | Title | Version | Status |
|---|---|---|---|
| NEO-AI-R-009 (requested, not allocated) | From Model Intelligence to System Intelligence | v1.0 | DRAFT |

## Compatibility

| Requires | Why |
|---|---|
| Apache with `mod_rewrite` | the identifier resolver and the trailing-slash rule |
| Apache with `mod_headers` | PDF robots tag, security headers, cache control |
| `mod_expires`, `mod_deflate` | optional; wrapped in `<IfModule>` and degrade silently |
| Document root = subdomain root | every new asset path is root-relative |
| Python 3.8+, `markdown>=3.4` | **rebuild only**, never at deploy time |
| Node + Playwright | **PDF regeneration only** |

## Next version

`research-delta-1.1.0` is a content import, not an engineering release: drop a
cleared text in, flip `content_present`, rebuild, upload. See
`DEVELOPER_HANDOFF.md` §5.
