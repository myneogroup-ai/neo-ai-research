# Developer handoff

Assume you know nothing about this project. This is everything you need.

---

## 1. What you are deploying

The NEO AI Research Program's public corpus, as a static tree added to the live
site at `neoai.myneogroup.com`, plus six changed files. No framework, no build
step required at deploy time, no server-side dependency beyond Apache.

`upload/` is **pre-built and complete**. You can deploy without running
anything.

## 2. The stack you are deploying into

Static HTML, vanilla JavaScript, Apache on shared hosting, PHP available for the
existing contact relay. The new pages match it exactly: server-rendered HTML,
one 6.1 KB progressive-enhancement script, no dependency.

**Research pages do not load any of the existing site JavaScript.**
`app-runtime.min.js` dereferences `#langSel` without a guard and throws when
that element is absent, which would kill every later script on the page. This is
asserted by a build check, not left to discipline.

## 3. Deploy

`DEPLOYMENT_ORDER.md`. Two preconditions, eleven steps, about 20 minutes.
The condensed version is in `README_FIRST.md`.

## 4. Rebuild, if you need to

You do not need to for this release. You will for the next one.

```bash
cd build
pip install 'markdown>=3.4'          # the only dependency
python3 neo_research_build.py        # writes ../upload
python3 patch_index.py               # writes ../upload/index.html
node make_pdf.js                     # writes ../upload/pdf/...   (needs playwright)
python3 gen_docs.py                  # regenerates manifest, tree, route map
python3 verify_delta.py              # 1,605 checks. must print PASS
```

`--check` on either Python builder fails if the tree on disk differs from what
the registers would produce. That is what a CI job should run.

| Script | Does |
|---|---|
| `neo_research_build.py` | renders every route, sitemap, feed, `llms.txt`, search index, `.htaccess`, `404.html`, and the print HTML |
| `patch_index.py` | applies the six landing-page insertions, asserting each anchor occurs exactly once |
| `make_pdf.js` | renders the print HTML to `pdf/<PUBID>/v1.0.pdf` |
| `gen_docs.py` | regenerates `FILE_MANIFEST`, `FILE_TREE`, `ROUTE_MAP` from the built tree |
| `verify_delta.py` | the conformance gate |

## 5. Publishing the next document

This is the case the package is built for. When a public text clears editorial
review:

1. Put the markdown at the path the register already records in `content_path`,
   under `build/corpus/`.
2. In `build/corpus/registers/publications.json`, set `content_present: true`
   for that entry — and `publish: true` if it was held for a later wave.
3. `python3 neo_research_build.py && python3 verify_delta.py`
4. `node make_pdf.js && python3 gen_docs.py`
5. Upload the changed files.

**Everything follows automatically**: the library index, the category index, the
sitemaps, the feeds, `llms.txt`, the search index, the identifier resolver rule
in `.htaccess`, the roadmap tables, and any topic hub that now has a resolving
member. No page lists a publication because somebody typed it into an index.

The build **fails** rather than shipping if the text claims a capability key
that is not in the register, or claims a status the register disagrees with.

## 6. Changing a capability status

Edit `build/corpus/registers/capabilities.json`, rebuild. Every page that
mentions that key updates, and `/capabilities.json` updates with it.

**Then read every publication that referenced it.** The injected token updates;
the surrounding sentence may still assert the old reality. That part is not
automatable and it is the part that is easy to skip.

## 7. Where things live

```
build/
  corpus/          the frozen research repository, unmodified
  source/          byte-identical copy of the deployed index.html
  assets/          authored CSS and JS, copied into upload/
  pdf-src/         generated print HTML
  *.py *.js        the build and verification scripts
upload/            what goes on the server
QA_EVIDENCE/       measurements and screenshots
*.md               documentation
```

## 8. Conventions that are not negotiable

They come from the corpus's own standards, and the build enforces the
machine-checkable ones.

- A canonical URL never redirects. An identifier route always 302s. A pinned
  version is immutable and is never redirected forward.
- Slugs are frozen at first publication.
- `lastmod` comes from the register, never from a file timestamp.
- No page lists a title that does not resolve.
- No capability status is written by an author.
- Feeds carry the abstract, never the body.
- No internal identifier, path or instrument name reaches a public page.
- Structured data never asserts more than the visible page.

## 9. Things that will look wrong and are not

| Looks wrong | Is correct because |
|---|---|
| Only one publication | Five approved texts are not yet cleared; three more are held for Wave 1b. `README_FIRST.md` |
| Two category indexes list nothing | The page exists so a link to it never breaks, and it lists nothing rather than something that does not resolve |
| Three topic hubs 404 | No member resolves. They appear automatically when one does |
| The glossary has no definitions | The term set is final, the definitional text is not published. A term list without definitions is honest; an invented definition is not |
| `sitemaps/figures.xml` is empty | The file exists so the sitemap index does not point at a 404 |
| `/id/NEO-AI-R-001` returns 404 | Registered, not drafted. Redirecting it would make an unresolvable identifier appear to resolve |
| No `citation_technical_report_number` | R-009's identifier is requested and not allocated. Omitted, not invented |
| No ORCID | Not registered. **This one is a real blocker** — see `AUDIT_CTO_FINAL.md` F-1 |

## 10. Who decides what

| Question | Not you |
|---|---|
| Whether a text may be published | Research Program, then Founder |
| Whether a capability status may change | Founder |
| Whether a claim may be strengthened | Founder. It never is between an internal document and a public one |
| Whether to retire the legacy `/neoai/` subpath | Founder — and it needs deciding this week |
| ORCID registration | Founder |
| Whether to build the eleven platform routes | Founder |

Anything on that list that reaches you as a request should go back with this
document attached.
