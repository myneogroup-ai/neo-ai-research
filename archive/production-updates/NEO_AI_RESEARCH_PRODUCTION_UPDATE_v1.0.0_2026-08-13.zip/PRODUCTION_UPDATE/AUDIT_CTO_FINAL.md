# Final production audit

Written as the CTO receiving this package for deployment, having been given
nothing else. The question is not "is it good work" but **"can I deploy this on
Monday without asking anyone a question, and what breaks if I do."**

**Verdict: deployable.** Two items need a decision from the Founder, not from
engineering, and neither blocks the deploy. One of them (F-1) blocks *first
publication* under the corpus's own standard, which is a different gate.

---

## 1. What I actually verified, and how

Not by reading the code. By running it.

| Verification | Method | Result |
|---|---|---|
| Conformance | `verify_delta.py`, **1,605 assertions** over the built tree | **PASS**, no finding |
| Routing, redirects, status codes | **Apache 2.4.58**, `AllowOverride All`, the shipped `.htaccess` in place, 31 routes exercised | **31/31 as specified** |
| `.htaccess` validity | `apache2ctl configtest` | **Syntax OK** |
| Response headers | live `curl` against that Apache | canonical `Link` on the PDF, `X-Robots-Tag`, three security headers, `must-revalidate` on the four discovery files, gzip 72.5 KB → 17.6 KB |
| Horizontal overflow | headless Chromium, 15 routes at 360px | **zero** |
| Navigation width | 20 viewports, 360–1920px, patched and unpatched | **no viewport overflow on either surface** |
| Landing page after patching | headless Chromium: 18 languages, French and Arabic switch, legal modal, `?legal=` deep link | **no page error, all behaviours intact** |
| Contrast | computed WCAG 2.2 ratios for all nine text colours | **all pass AA-normal**; the weakest is 4.58:1 |
| PDF | rendered, 14 pages A4, page images inspected | correct |
| Classification | regex sweep of every file in `upload/` | **no internal identifier, gate, audit reference or filesystem path** |

Evidence in `QA_EVIDENCE/`: the conformance run, the Apache route tests, the
header dump, the nav-width tables, 24 screenshots.

## 2. Completeness, checked against the brief

| Required | Delivered |
|---|---|
| New routes with metadata, canonical, breadcrumb, structured data | 41 HTML routes, `ROUTE_MAP.md` |
| Every file generated | 68 files in `upload/`, `FILE_MANIFEST.md` with SHA-256 |
| Exhaustive list of files to modify | 6 files, 8 changes, byte-exact anchors, `MODIFICATIONS.md` + a unified diff |
| Structured data: every entity, collection, article, breadcrumb, dataset | delivered and validated internally, `STRUCTURED_DATA.md` |
| SEO: robots, llms, sitemaps, feeds, canonical, hreflang, OG, Twitter | delivered, **except `hreflang`** — see F-3 |
| Search | delivered, `SEARCH.md` |
| Images | **none exist.** Fully specified instead, `IMAGES.md` |
| Components | delivered as build-time templates, **not React** — see F-2 |
| Navigation | delivered, `NAVIGATION.md` |
| Documentation | 20 documents |
| Deployment order, cache, verification, rollback, post-deploy QA | delivered |
| QA checklist | 118 manual checks over 1,605 automated ones |

## 3. What I would reject a package for, and did not find here

- A route in a sitemap that 404s — checked, none
- A canonical that points somewhere else — checked, all self
- Structured data asserting something the page does not render — checked
- A capability status typed by hand — impossible; **the build fails** on a key
  that is not in the register or a status that disagrees with it
- An index listing a title that does not resolve — impossible by construction
- A modification described but not supplied — every one has a byte-exact anchor
  and a diff
- Placeholder text shipped as content — checked; the two literal placeholders in
  the frozen entity graph are **omitted**, not published
- A rollback that has not been thought through — five levels, smallest first

## 4. Findings. Eight. None blocks the deploy.

### F-1 · No ORCID. **Blocks first publication, not deployment.** Founder.

`docs/11_STRUCTURED_DATA.md` states: *"An ORCID identifier is registered before
first publication and appears on the `Person` and on every article's author
reference."* None is registered.

The frozen `schema/entities.jsonld` carried the literal string
`ORCID_TO_BE_REGISTERED_BEFORE_FIRST_PUBLICATION`, and `sameAs` carried
`REAL_CONTROLLED_RECIPROCAL_PROFILES_ONLY`. **Publishing either would have been
worse than publishing nothing**, so both fields are omitted and the author page
says plainly that no ORCID is displayed because none is registered.

The corpus is deployable in that state. Whether it should be *published* in that
state is a Founder call against the Program's own standard. Registration takes
minutes and is free.

### F-2 · No React or Next.js. **Deliberate. Read before objecting.**

The brief asked for a React/Next component inventory. The deployed stack is
static HTML, vanilla JS and Apache — no bundler, no `package.json`, no Node on
the server. Introducing React would mean two rendering models on one site, a
toolchain the deploy process does not have, and a client-rendered document at
exactly the moment the corpus's own standard requires the entire body in the
initial HTML response.

`COMPONENTS.md` inventories every component as a build-time template and maps
them one-to-one onto a future component tree. If the answer is "we want Next.js
anyway", that is a migration, not a delta, and this package is the content and
data layer it would consume.

### F-3 · No `hreflang`, and no indexable translation. **Founder decision.**

Eighteen languages, one URL. The selector swaps text nodes and creates no route,
so every `hreflang` would point at the same document and reciprocity could not
be satisfied. Emitting it would be a false signal.

Eighteen dictionaries of translated copy currently have **zero search surface**.
That is a real commercial cost and it is older than this release.
`PREEXISTING_DEFECTS.md` D-4 sets out the fix as its own release.

### F-4 · No `og:image`. **Needs a designer, one hour.**

Shared links render as text cards. Better than today's bare URL, worse than it
should be. Three images fully specified in `IMAGES.md` §3 — dimensions,
palette, type, safe area, and the deliberate exclusion of any status token from
a card, because a card is quoted without its qualifiers.

### F-5 · The PDF is not tagged. **Accessibility gap, disclosed.**

`pdfinfo` reports `Tagged: no`. It is generated by Chromium's print pipeline,
which produces no structure tree, so the PDF is not PDF/UA conformant: a screen
reader gets reading order by heuristic rather than by structure.

Mitigated by the HTML being the canonical artefact and fully accessible, and by
the PDF carrying an HTTP `Link` header pointing back to it. If PDF/UA becomes a
requirement, the generator changes, not the content.

### F-6 · Glossary linking sits at the bottom of its band. **Content, not code.**

The linking standard asks for 5–15 distinct glossary terms linked per
publication. R-009 achieves **5**. Nineteen defined terms appear in the paper,
but most occur only inside the capability table, inside claim chips, or in the
backticked Related Terms list — all exclusion zones, correctly.

I found and fixed a real bug here during the audit: the first-occurrence matcher
excluded any term preceded by `>`, which silently skipped every emphasised
term. That took it from 4 to 5. The remaining shortfall is a property of the
text, not of the build, and it resolves itself as the corpus grows.

### F-7 · Three topic hubs 404 and the platform sitemap lists one URL.

Both are corrections to the frozen artefacts, not omissions. `gen_seo.py`
hardcoded five hubs (three would have shipped empty and indexed) and twelve
platform routes (eleven do not exist). Hub membership is now derived and the
build reports what it skipped. `ROUTE_MAP.md` §5 and §6.

### F-8 · Structured data is not externally validated.

Every check I could run offline passes — parsing, `@id` resolution, prohibited
types, rendered-counterpart agreement on the claim counts. **It has not been
through `validator.schema.org` or Google's Rich Results Test**, because both
need the pages to be reachable. `QA_CHECKLIST.md` §F is the post-deploy pass.
I would not hold a deploy for this; I would hold sign-off.

## 5. What I am explicitly NOT fixing, and why

| Not fixed | Why |
|---|---|
| Content-Security-Policy | `index.html` carries an inline config script and an inline `<style>`. A CSP added without auditing them breaks the landing page. Its own change |
| Landing-page mobile menu | Below 1080px the nav has no replacement. A design change, not a defect fix. D-6 |
| Landing-page `<main>` and skip link | Requires restructuring a regression-locked document. D-7. Bundle with the above |
| The eleven platform routes | Content is finalized; building them is a separate release |
| Glossary definitions | The source is an internal editorial standard carrying unapproved definitions. **An invented definition is worse than an absent one** |
| The five uncleared Wave 1 texts | Two of the required edits remove material classified above PUBLIC. Not mine to write, and not anyone's to guess |

## 6. The two decisions I need this week

**D-1, the legacy subpath.** If `myneogroup.com/neoai/` still serves the site,
this release publishes a corpus of permanent citable URLs onto a host that a
search engine may already treat as a duplicate. The fix is one line in the
WordPress root and it is not in this package because it cannot be.
**This gets more expensive every day it is left.**

**F-1, the ORCID.** Free, minutes, and the Program's own standard says first
publication waits for it.

## 7. Residual risk, stated honestly

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| `.htaccess` 500s the site | low — `configtest` clean, tested on Apache 2.4.58 | high, whole site | uploaded alone, step 2; restore takes 30 seconds |
| P2 false and pages render unstyled | low — verified true today | high, research only | precondition, checked before anything |
| M-08 reflows the landing page badly | medium — the metric change is real | medium, cosmetic | QA §B; deleting one line reverses it |
| A capability status drifts from the register | very low | **severe, reputational** | the build fails closed; QA A10/A11 have no tolerance band |
| A reader mistakes DRAFT for approved | low | medium | status rendered in the header, in the meta line, in the PDF and in the structured data |
| Search Console reports the new URLs as duplicates | **medium, if D-1 is not resolved** | high | resolve D-1 |

The severe risk on that list is not technical. It is the one the corpus is built
to prevent: a capability described as operational that is not. Three independent
mechanisms guard it — the build fails on a mismatch, `verify_delta.py` check
SD10 re-checks the built output, and QA A10/A11 stop the deployment. That is the
right amount of redundancy for the one failure mode that retroactively converts
every other page into marketing.

## 8. Sign-off

**This package is deployment-ready.** A developer who has read `README_FIRST.md`
and `DEPLOYMENT_ORDER.md` can deploy it without asking a question. Everything
they need is supplied: the files, the diffs, the anchors, the checksums, the
order, the verification commands, the rollback, and the evidence.

Two things must not be silently skipped: precondition **P2**, and the decision on
**D-1**. Everything else on the findings list is scheduled work, not a blocker.

| | |
|---|---|
| Audited | 13 August 2026 |
| Against | deployed `v17.2`, `sha256 836bbfb…dc1ee6` |
| Conformance | 1,605 automated checks, PASS |
| Routing | 31 routes on Apache 2.4.58, all as specified |
| Findings | 8 — 0 blocking deployment, 1 blocking first publication, 2 needing a Founder decision |
